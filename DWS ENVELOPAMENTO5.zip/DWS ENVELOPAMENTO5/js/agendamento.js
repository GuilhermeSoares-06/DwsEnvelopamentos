document.addEventListener('DOMContentLoaded', function() {
    console.log('=== AGENDAMENTO.JS INICIALIZADO ===');

    // =============================================
    // VARIÁVEIS GLOBAIS
    // =============================================
    let dataSelecionada = null;
    let horarioSelecionado = null;
    let servicoSelecionado = null;
    let precoBaseSelecionado = 0;
    let calendar = null;

    // =============================================
    // VERIFICA SE USUÁRIO ESTÁ LOGADO (localStorage)
    // =============================================
    function verificarUsuarioLogado() {
        console.log('Verificando usuário logado...');
        
        const nomeLogado = localStorage.getItem('clinome') || '';
        const telefoneLogado = localStorage.getItem('clitel') || '';
        const cpfLogado = localStorage.getItem('clicpf') || '';
        
        console.log('Dados localStorage:', { nomeLogado, telefoneLogado, cpfLogado });
        
        if (nomeLogado) {
            // Preenche os campos
            const nomeInput = document.getElementById('nome');
            const telefoneInput = document.getElementById('telefone');
            const cpfInput = document.getElementById('cpf');
            
            if (nomeInput && !nomeInput.value) {
                nomeInput.value = nomeLogado;
                console.log('Nome preenchido:', nomeLogado);
            }
            if (telefoneInput && !telefoneInput.value) {
                telefoneInput.value = telefoneLogado;
                console.log('Telefone preenchido:', telefoneLogado);
            }
            if (cpfInput && !cpfInput.value) {
                cpfInput.value = cpfLogado;
                console.log('CPF preenchido:', cpfLogado);
            }
            
            return true;
        }
        return false;
    }

    // =============================================
    // INICIALIZA CALENDÁRIO
    // =============================================
    function inicializarCalendario() {
        const calendarEl = document.getElementById('calendario');
        if (!calendarEl) {
            console.error('Elemento calendario não encontrado!');
            return;
        }

        console.log('Inicializando calendário...');
        
        calendar = new FullCalendar.Calendar(calendarEl, {
            locale: 'pt-br',
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth'
            },
            selectable: true,
            selectMirror: true,
            dayMaxEvents: true,
            weekends: true,
            select: function(info) {
                const data = info.startStr;
                console.log('Data selecionada (select):', data);
                selecionarData(data);
            },
            dateClick: function(info) {
                const data = info.dateStr;
                console.log('Data selecionada (dateClick):', data);
                selecionarData(data);
            }
        });
        calendar.render();
        console.log('Calendário renderizado com sucesso!');
    }

    // =============================================
    // SELECIONA DATA
    // =============================================
    function selecionarData(data) {
        console.log('selecionarData chamado com:', data);
        dataSelecionada = data;
        
        const dataSpan = document.getElementById('dataSelecionada');
        if (dataSpan) {
            dataSpan.textContent = formatarData(data);
        }
        
        // Atualiza a data no campo hidden
        const dataInput = document.getElementById('dataAgendamentoHidden');
        if (dataInput) {
            dataInput.value = data;
            console.log('Hidden data_agendamento setado:', data);
        }
        
        // Carrega horários disponíveis
        carregarHorarios(data);
        
        // Destaca a data no calendário
        if (calendar) {
            calendar.unselect();
            calendar.select(data);
        }
    }

    // =============================================
    // CARREGA HORÁRIOS
    // =============================================
    function carregarHorarios(data) {
        console.log('carregarHorarios chamado com data:', data);
        const container = document.getElementById('horariosList');
        if (!container) return;
        
        container.innerHTML = '<div class="text-center text-white p-4">Carregando horários...</div>';
        
        // Horários disponíveis
        const horarios = [
            '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
            '11:00', '11:30', '12:00', '13:00', '13:30', '14:00',
            '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
        ];
        
        container.innerHTML = '';
        horarios.forEach(hora => {
            const btn = document.createElement('button');
            btn.className = 'horario-btn';
            btn.textContent = hora;
            btn.dataset.horario = hora;
            
            btn.addEventListener('click', function() {
                console.log('Horário selecionado:', hora);
                selecionarHorario(hora);
            });
            
            container.appendChild(btn);
        });
        
        console.log('Horários carregados:', horarios.length);
    }

    // =============================================
    // SELECIONA HORÁRIO
    // =============================================
    function selecionarHorario(hora) {
        console.log('selecionarHorario chamado com:', hora);
        horarioSelecionado = hora;
        
        const horarioSpan = document.getElementById('horarioSelecionado');
        if (horarioSpan) {
            horarioSpan.textContent = hora;
        }
        
        // Atualiza o campo hidden
        const horaInput = document.getElementById('horarioAgendamentoHidden');
        if (horaInput) {
            horaInput.value = hora;
            console.log('Hidden horario_agendamento setado:', hora);
        }
        
        // Destaca o botão selecionado
        document.querySelectorAll('.horario-btn').forEach(btn => {
            btn.classList.remove('selecionado');
            if (btn.dataset.horario === hora) {
                btn.classList.add('selecionado');
            }
        });
        
        atualizarResumo();
    }

    // =============================================
    // SELECIONA SERVIÇO
    // =============================================
    function selecionarServico(card) {
        console.log('selecionarServico chamado');
        
        // Remove seleção anterior
        document.querySelectorAll('.servico-card').forEach(c => c.classList.remove('selecionado'));
        card.classList.add('selecionado');
        
        servicoSelecionado = card.dataset.tipo;
        precoBaseSelecionado = parseFloat(card.dataset.precoBase) || 0;
        
        console.log('Serviço selecionado:', servicoSelecionado, 'Preço base:', precoBaseSelecionado);
        
        const servicoSpan = document.getElementById('servicoResumo');
        if (servicoSpan) {
            servicoSpan.textContent = card.querySelector('h4')?.textContent || servicoSelecionado;
        }
        
        // Atualiza campo hidden
        const tipoInput = document.getElementById('tipoServicoHidden');
        if (tipoInput) {
            tipoInput.value = servicoSelecionado;
            console.log('Hidden tipo_servico setado:', servicoSelecionado);
        }
        
        atualizarResumo();
    }

    // =============================================
    // ATUALIZA RESUMO
    // =============================================
    function atualizarResumo() {
        const acabamentoSelect = document.getElementById('acabamento');
        const fator = parseFloat(acabamentoSelect?.value || '1.0');
        
        let valorBase = precoBaseSelecionado || 0;
        let valorFinal = valorBase * fator;
        
        const valorBaseSpan = document.getElementById('valorBase');
        const valorTotalSpan = document.getElementById('valorTotal');
        const valorAcabamentoSpan = document.getElementById('valorAcabamento');
        
        if (valorBaseSpan) valorBaseSpan.textContent = formatarMoeda(valorBase);
        if (valorTotalSpan) valorTotalSpan.textContent = formatarMoeda(valorFinal);
        
        const acrescimo = ((fator - 1) * 100);
        if (valorAcabamentoSpan) {
            valorAcabamentoSpan.textContent = acrescimo > 0 ? `+${acrescimo}%` : '0%';
        }
        
        // Atualiza campos hidden
        const valorBaseInput = document.getElementById('valorBaseHidden');
        const valorTotalInput = document.getElementById('valorTotalHidden');
        if (valorBaseInput) {
            valorBaseInput.value = valorBase.toFixed(2);
            console.log('Hidden valor_base setado:', valorBase.toFixed(2));
        }
        if (valorTotalInput) {
            valorTotalInput.value = valorFinal.toFixed(2);
            console.log('Hidden valor_total setado:', valorFinal.toFixed(2));
        }
    }

    // =============================================
    // FORMATADORES
    // =============================================
    function formatarData(data) {
        if (!data) return 'Nenhuma';
        try {
            const d = new Date(data + 'T00:00:00');
            return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
        } catch (e) {
            return data;
        }
    }

    function formatarMoeda(valor) {
        return 'R$ ' + parseFloat(valor || 0).toFixed(2).replace('.', ',');
    }

    // =============================================
    // ENVIA AGENDAMENTO - VERSÃO CORRIGIDA
    // =============================================
    function enviarAgendamento() {
        console.log('=== ENVIANDO AGENDAMENTO ===');
        
        // Pega os dados dos campos
        const nome = document.getElementById('nome')?.value || '';
        const telefone = document.getElementById('telefone')?.value || '';
        const cpf = document.getElementById('cpf')?.value || '';
        const email = document.getElementById('email')?.value || '';
        const veiculo = document.getElementById('veiculo')?.value || '';
        const descricao = document.getElementById('descricao')?.value || '';
        const acabamento = document.getElementById('acabamento')?.value || '1.0';
        
        console.log('Dados do formulário:', {
            nome, telefone, cpf, email, veiculo, descricao, acabamento,
            dataSelecionada, horarioSelecionado, servicoSelecionado
        });
        
        // =============================================
        // VALIDAÇÕES
        // =============================================
        if (!dataSelecionada) {
            mostrarToast('Selecione uma data.', 'error');
            return;
        }
        if (!horarioSelecionado) {
            mostrarToast('Selecione um horário.', 'error');
            return;
        }
        if (!servicoSelecionado) {
            mostrarToast('Selecione um serviço.', 'error');
            return;
        }
        if (!nome.trim()) {
            mostrarToast('Preencha o nome.', 'error');
            return;
        }
        if (!telefone.trim()) {
            mostrarToast('Preencha o telefone.', 'error');
            return;
        }
        if (!veiculo.trim()) {
            mostrarToast('Preencha o veículo/mobília.', 'error');
            return;
        }
        if (!descricao.trim()) {
            mostrarToast('Preencha a descrição do serviço.', 'error');
            return;
        }
        
        // =============================================
        // PREPARA DADOS PARA ENVIO
        // =============================================
        const formData = new FormData();
        formData.append('nome', nome.trim());
        formData.append('telefone', telefone.trim());
        formData.append('cpf', cpf.trim());
        formData.append('email', email.trim());
        formData.append('veiculo', veiculo.trim());
        formData.append('descricao', descricao.trim());
        formData.append('tipo_servico', servicoSelecionado);
        formData.append('acabamento', acabamento);
        formData.append('data_agendamento', dataSelecionada);
        formData.append('horario_agendamento', horarioSelecionado);
        formData.append('valor_base', document.getElementById('valorBaseHidden')?.value || '0');
        formData.append('valor_total', document.getElementById('valorTotalHidden')?.value || '0');
        
        // LOG DOS DADOS ENVIADOS
        console.log('Dados enviados via FormData:');
        for (let [key, value] of formData.entries()) {
            console.log(`  ${key}: ${value}`);
        }
        
        // =============================================
        // ENVIA PARA O PHP
        // =============================================
        const btn = document.getElementById('btnAgendar');
        const textoOriginal = btn?.innerHTML || 'Confirmar Agendamento';
        if (btn) {
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
            btn.disabled = true;
        }
        
        console.log('Enviando requisição para agendar.php...');
        
        fetch('../Banco/agendar.php', {
            method: 'POST',
            body: formData,
            credentials: 'include' // Envia cookies de sessão
        })
        .then(response => {
            console.log('Resposta recebida, status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Dados da resposta:', data);
            
            if (btn) {
                btn.innerHTML = textoOriginal;
                btn.disabled = false;
            }
            
            if (data.status === 'sucesso') {
                mostrarToast(data.mensagem || 'Agendamento realizado com sucesso!', 'success');
                if (data.whatsapp_url) {
                    console.log('Abrindo WhatsApp:', data.whatsapp_url);
                    setTimeout(() => {
                        window.open(data.whatsapp_url, '_blank');
                    }, 1500);
                }
                // Limpa seleções após sucesso
                setTimeout(() => {
                    resetarFormulario();
                }, 3000);
            } else {
                mostrarToast(data.mensagem || 'Erro ao agendar. Tente novamente.', 'error');
            }
        })
        .catch(error => {
            console.error('ERRO na requisição:', error);
            if (btn) {
                btn.innerHTML = textoOriginal;
                btn.disabled = false;
            }
            mostrarToast('Erro de conexão. Verifique sua internet e tente novamente.', 'error');
        });
    }

    // =============================================
    // RESETA FORMULÁRIO
    // =============================================
    function resetarFormulario() {
        console.log('Resetando formulário...');
        dataSelecionada = null;
        horarioSelecionado = null;
        servicoSelecionado = null;
        precoBaseSelecionado = 0;
        
        const dataSpan = document.getElementById('dataSelecionada');
        const horarioSpan = document.getElementById('horarioSelecionado');
        const servicoSpan = document.getElementById('servicoResumo');
        const valorBaseSpan = document.getElementById('valorBase');
        const valorTotalSpan = document.getElementById('valorTotal');
        const valorAcabamentoSpan = document.getElementById('valorAcabamento');
        
        if (dataSpan) dataSpan.textContent = 'Nenhuma';
        if (horarioSpan) horarioSpan.textContent = 'Nenhum';
        if (servicoSpan) servicoSpan.textContent = 'Nenhum';
        if (valorBaseSpan) valorBaseSpan.textContent = 'R$ 0,00';
        if (valorTotalSpan) valorTotalSpan.textContent = 'R$ 0,00';
        if (valorAcabamentoSpan) valorAcabamentoSpan.textContent = '0%';
        
        document.querySelectorAll('.horario-btn').forEach(btn => btn.classList.remove('selecionado'));
        document.querySelectorAll('.servico-card').forEach(c => c.classList.remove('selecionado'));
        
        if (calendar) {
            calendar.unselect();
        }
        
        // Limpa campos hidden
        const hiddenFields = ['dataAgendamentoHidden', 'horarioAgendamentoHidden', 'tipoServicoHidden', 'valorBaseHidden', 'valorTotalHidden'];
        hiddenFields.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
    }

    // =============================================
    // TOAST
    // =============================================
    function mostrarToast(mensagem, tipo = 'success') {
        console.log('Toast:', tipo, '-', mensagem);
        const toast = document.getElementById('toastMsg');
        const text = document.getElementById('toastText');
        
        if (!toast || !text) {
            alert(mensagem);
            return;
        }
        
        text.textContent = mensagem;
        toast.className = 'toast-notification';
        if (tipo === 'error') {
            toast.classList.add('error');
        }
        toast.style.display = 'flex';
        toast.style.opacity = '1';
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.style.display = 'none';
                toast.className = 'toast-notification';
            }, 500);
        }, 4000);
    }

    // =============================================
    // CONFIGURAÇÃO DOS EVENTOS
    // =============================================
    
    // 1. Serviços - clique para selecionar
    document.querySelectorAll('.servico-card').forEach(card => {
        card.addEventListener('click', function() {
            selecionarServico(this);
        });
    });

    // 2. Acabamento - mudança no select
    const acabamentoSelect = document.getElementById('acabamento');
    if (acabamentoSelect) {
        acabamentoSelect.addEventListener('change', function() {
            console.log('Acabamento alterado:', this.value);
            atualizarResumo();
        });
    }

    // 3. Botão de agendamento
    const btnAgendar = document.getElementById('btnAgendar');
    if (btnAgendar) {
        btnAgendar.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Botão Confirmar Agendamento clicado!');
            enviarAgendamento();
        });
        console.log('Botão de agendamento configurado');
    } else {
        console.error('Botão btnAgendar não encontrado!');
    }

    // =============================================
    // INICIALIZAÇÃO
    // =============================================
    console.log('Inicializando agendamento...');
    inicializarCalendario();
    verificarUsuarioLogado();
    atualizarResumo();
    
    console.log('=== AGENDAMENTO.JS INICIALIZADO COM SUCESSO ===');
});
function salvarDadosUsuario(dados) {
    if (dados.cliid) {
        localStorage.setItem('cliid', dados.cliid);
        localStorage.setItem('clinome', dados.clinome || '');
        localStorage.setItem('clitel', dados.clitel || '');
        localStorage.setItem('clicpf', dados.clicpf || '');
        localStorage.setItem('cliendereco', dados.cliendereco || '');
        
        // Salva a foto se existir
        const foto = document.getElementById('userIcon')?.src;
        if (foto && !foto.includes('icon.user2')) {
            localStorage.setItem('fotoPerfilDWS', foto);
        }
        
        console.log('Dados do usuário salvos no localStorage');
        return true;
    }
    return false;
}

function limparDadosUsuario() {
    localStorage.removeItem('cliid');
    localStorage.removeItem('clinome');
    localStorage.removeItem('clitel');
    localStorage.removeItem('clicpf');
    localStorage.removeItem('cliendereco');
    localStorage.removeItem('fotoPerfilDWS');
    console.log('Dados do usuário removidos do localStorage');
}

// Função para verificar se o usuário está logado
function isUsuarioLogado() {
    return !!localStorage.getItem('cliid');
}

// Função para obter os dados do usuário
function getDadosUsuario() {
    return {
        cliid: localStorage.getItem('cliid'),
        clinome: localStorage.getItem('clinome'),
        clitel: localStorage.getItem('clitel'),
        clicpf: localStorage.getItem('clicpf'),
        cliendereco: localStorage.getItem('cliendereco')
    };
}
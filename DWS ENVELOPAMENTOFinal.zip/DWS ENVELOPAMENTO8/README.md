# DWS Envelopamento — PHP 8.x + MySQL/MariaDB (sem framework)

## Requisitos
PHP >= 8.1 (testado 8.3.6) com `pdo_mysql, mbstring, curl, fileinfo, openssl` · MySQL 8 / MariaDB 10.x · Apache com `AllowOverride All` (XAMPP já vem assim). PHPMailer já está em `PHP/lib/`.

## Instalação
1. Copie a pasta para `htdocs` (ou raiz do site).
2. `mysql -u root -e "CREATE DATABASE dws CHARACTER SET utf8mb4"` e `mysql -u root dws < sql/schema.sql`
   (**schema.sql foi reconstruído a partir do código**: se você já tem banco, compare antes; use só `sql/funcionarios_email.sql` e `recuperacao_senha.sql` se for atualizar).
3. `cp PHP/Config/config.example.php PHP/Config/config.php` e preencha `db`, `app.url`, `mp`, `admin.super_admin_ids`.
4. Crie o 1º funcionário (hash bcrypt):  
   `php -r 'echo password_hash("SuaSenha@123", PASSWORD_DEFAULT);'` e insira em `funcionarios` (id 1 = super admin).
5. E-mail ("Esqueci minha senha"): veja `LEIA-ME_EMAIL.txt`.
6. Produção: `app.env=production`, `app.debug=false`, `mp.modo_teste=false`, apague `configurar_email.php`, `testar_email.php`, `diagnostico_login.php`.

## Testes
`tests/regressao.sh` (precisa de `php -S 127.0.0.1:8083 -t .`, MySQL com `dws` e usuário de teste no config). 19 verificações.

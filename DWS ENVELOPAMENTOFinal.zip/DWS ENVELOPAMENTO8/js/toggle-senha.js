// =============================================
// toggle-senha.js — Botão "mostrar/ocultar senha"
// Adiciona um olho em TODO <input type="password"> da página.
// Basta incluir: <script src="../../js/toggle-senha.js" defer></script>
// =============================================
(function () {
  'use strict';

  var OLHO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  var OLHO_RISCADO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.9 10.9 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.06-5.94M9.9 4.24A10.9 10.9 0 0 1 12 4c7 0 11 7 11 7a19.7 19.7 0 0 1-3.17 4.19M14.12 14.12A3 3 0 1 1 9.88 9.88"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';

  var css = '.dws-pw-wrap{position:relative;display:block;width:100%}' +
    '.dws-pw-btn{position:absolute;top:50%;right:12px;transform:translateY(-50%);background:none;border:0;padding:6px;' +
    'cursor:pointer;color:#888;display:flex;align-items:center;justify-content:center;border-radius:8px;line-height:0;z-index:3}' +
    '.dws-pw-btn:hover,.dws-pw-btn:focus-visible{color:#f23535;outline:none;background:rgba(242,53,53,.12)}' +
    '.dws-pw-btn.ativo{color:#f23535}' +
    '.dws-pw-btn.com-status{right:40px}' +
    'input.dws-pw-input{padding-right:48px !important}';

  function injetarCss() {
    if (document.getElementById('dwsPwCss')) return;
    var s = document.createElement('style');
    s.id = 'dwsPwCss';
    s.textContent = css;
    document.head.appendChild(s);
  }

  function aplicar(input) {
    if (input.dataset.dwsPw === '1') return;
    input.dataset.dwsPw = '1';

    var pai = input.parentElement;
    var container;
    if (pai && pai.classList.contains('input-box')) {
      container = pai; // já é position:relative nas telas do projeto
      if (getComputedStyle(pai).position === 'static') pai.style.position = 'relative';
    } else {
      container = document.createElement('div');
      container.className = 'dws-pw-wrap';
      pai.insertBefore(container, input);
      container.appendChild(input);
    }

    var temStatus = !!container.querySelector('.input-status');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'dws-pw-btn' + (temStatus ? ' com-status' : '');
    btn.innerHTML = OLHO;
    btn.setAttribute('aria-label', 'Mostrar senha');
    btn.setAttribute('aria-pressed', 'false');
    btn.title = 'Mostrar senha';
    input.classList.add('dws-pw-input');

    // não tira o foco do campo ao clicar no olho
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function () {
      var mostrar = input.type === 'password';
      input.type = mostrar ? 'text' : 'password';
      btn.innerHTML = mostrar ? OLHO_RISCADO : OLHO;
      btn.classList.toggle('ativo', mostrar);
      btn.setAttribute('aria-pressed', mostrar ? 'true' : 'false');
      var rot = mostrar ? 'Ocultar senha' : 'Mostrar senha';
      btn.setAttribute('aria-label', rot);
      btn.title = rot;
      input.focus({ preventScroll: true });
    });

    container.appendChild(btn);
  }

  function varrer() {
    document.querySelectorAll('input[type="password"]').forEach(aplicar);
  }

  // Login do cliente: garante o link "Esqueci minha senha" mesmo se o HTML estiver desatualizado
  function linkEsqueci() {
    var form = document.querySelector('form[action*="Logincliente.php"], form[action*="LoginADM.php"]');
    if (!form || document.querySelector('a[href*="esqueci_senha"]')) return;
    var senha = form.querySelector('input[type="password"]');
    if (!senha) return;
    var bloco = senha.closest('.input-box') || senha.parentElement;
    var div = document.createElement('div');
    div.style.cssText = 'text-align:center;margin:2px 0 16px;';
    div.innerHTML = '<a href="esqueci_senha.html" style="color:#f23535;font-size:.95rem;font-weight:600;text-decoration:none;">Esqueci minha senha</a>';
    bloco.parentNode.insertBefore(div, bloco.nextSibling);
  }

  function iniciar() {
    injetarCss();
    varrer();
    linkEsqueci();
    // campos criados depois (modais, etc.)
    if ('MutationObserver' in window) {
      new MutationObserver(varrer).observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();

# Publicar no InfinityFree (dwsenvelopamento.infinityfreeapp.com)

## 1. Banco de dados
1. Painel > conta **if0_43534606** > **MySQL Databases** > crie o banco (ex.: `dws` → fica `if0_43534606_dws`).
2. Anote: **MySQL Host Name** (algo como `sql123.infinityfree.com`), nome completo do banco, usuário e senha.
3. Abra o **phpMyAdmin** do banco > aba **Importar** > envie `sql/schema.sql`.
   (usa CREATE TABLE IF NOT EXISTS: não apaga nada se você já tem tabelas.)
4. Crie o primeiro funcionário (aba SQL). Gere o hash em qualquer PHP:  `echo password_hash('SuaSenha@123', PASSWORD_DEFAULT);`
   `INSERT INTO funcionarios (nome,usuario,senha,cargo_id) VALUES ('Seu Nome','seuusuario','COLE_O_HASH',NULL);`  (o 1º cadastrado tem id 1 = super admin)

## 2. Arquivos
1. Pelo **File Manager** ou FTP, envie TODO o conteúdo da pasta para dentro de **htdocs/** (index.php deve ficar em htdocs/index.php).
2. Em `htdocs/PHP/Config/`: copie `config.infinityfree.php` para **config.php** e preencha host, nome do banco e senha.
3. Abra https://dwsenvelopamento.infinityfreeapp.com/ — deve cair na página inicial.

## 3. Limitações do plano gratuito (verifique)
- **E-mail "Esqueci minha senha"**: hospedagem gratuita costuma bloquear SMTP/`mail()`. Se o código não chegar, o recurso não funcionará ali; alternativa: hospedagem paga ou outro provedor.
- **Mercado Pago (webhook)**: o InfinityFree injeta um teste anti-robô que pode barrar o POST do Mercado Pago. Mantenha `mp.modo_teste = true` (pagamento simulado) até testar de verdade.
- Apague depois de configurar: `diagnostico_login.php` e `PHP/Config/configurar_email.php`.

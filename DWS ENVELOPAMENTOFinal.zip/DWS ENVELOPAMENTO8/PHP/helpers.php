<?php
// =============================================
// helpers.php - Funções utilitárias
// =============================================

if (!function_exists('valorParaFloat')) {
    function valorParaFloat($valor): float {
        if (is_numeric($valor)) return (float)$valor;
        $valor = trim((string)$valor);
        $valor = str_replace(['R$', ' ', "\xc2\xa0"], '', $valor);
        $temVirgula = strpos($valor, ',') !== false;
        $temPonto   = strpos($valor, '.') !== false;
        if ($temVirgula && $temPonto) {
            $posV = strrpos($valor, ',');
            $posP = strrpos($valor, '.');
            if ($posV > $posP) {
                $valor = str_replace('.', '', $valor);
                $valor = str_replace(',', '.', $valor);
            } else {
                $valor = str_replace(',', '', $valor);
            }
        } elseif ($temVirgula) {
            $valor = str_replace(',', '.', $valor);
        }
        return (float)$valor;
    }
}

if (!function_exists('formatBr')) {
    function formatBr($valor): string {
        return number_format((float)$valor, 2, ',', '.');
    }
}

if (!function_exists('responderJson')) {
    function responderJson(array $dados, int $httpCode = 200): void {
        http_response_code($httpCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($dados, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('responderSucesso')) {
    function responderSucesso(string $mensagem, array $extras = []): void {
        responderJson(array_merge(['status' => 'sucesso', 'mensagem' => $mensagem], $extras));
    }
}

if (!function_exists('responderErro')) {
    function responderErro(string $mensagem, int $httpCode = 400, array $extras = []): void {
        responderJson(array_merge(['status' => 'erro', 'mensagem' => $mensagem], $extras), $httpCode);
    }
}

if (!function_exists('lerJsonEntrada')) {
    function lerJsonEntrada(): array {
        $raw = file_get_contents('php://input');
        $json = json_decode($raw, true);
        return is_array($json) ? $json : [];
    }
}

if (!function_exists('limparTelefone')) {
    function limparTelefone(string $telefone): string {
        return preg_replace('/\D/', '', $telefone);
    }
}

if (!function_exists('telefoneParaWhatsApp')) {
    function telefoneParaWhatsApp(string $telefone, string $dddPadrao = '14'): string {
        $tel = limparTelefone($telefone);
        if (strlen($tel) < 8) return '';
        $tel = ltrim($tel, '0');
        if (strlen($tel) === 13 || strlen($tel) === 12) return $tel;
        if (strlen($tel) === 11 || strlen($tel) === 10) return '55' . $tel;
        if (strlen($tel) === 9 || strlen($tel) === 8) return '55' . $dddPadrao . $tel;
        return '';
    }
}

if (!function_exists('formatarTelefone')) {
    function formatarTelefone(?string $telefone): string {
        if (empty($telefone)) return '';
        $tel = limparTelefone($telefone);
        if (strlen($tel) === 11) return '(' . substr($tel, 0, 2) . ') ' . substr($tel, 2, 5) . '-' . substr($tel, 7, 4);
        if (strlen($tel) === 10) return '(' . substr($tel, 0, 2) . ') ' . substr($tel, 2, 4) . '-' . substr($tel, 6, 4);
        return $telefone;
    }
}

if (!function_exists('validarCPF')) {
    function validarCPF(string $cpf): bool {
        $cpf = preg_replace('/\D/', '', $cpf);
        if (strlen($cpf) !== 11) return false;
        if (preg_match('/(\d)\1{10}/', $cpf)) return false;
        for ($t = 9; $t < 11; $t++) {
            $d = 0;
            for ($c = 0; $c < $t; $c++) {
                $d += (int)$cpf[$c] * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ((int)$cpf[$c] !== $d) return false;
        }
        return true;
    }
}

if (!function_exists('formatarCPF')) {
    function formatarCPF(string $cpf): string {
        $cpf = preg_replace('/\D/', '', $cpf);
        if (strlen($cpf) !== 11) return $cpf;
        return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
    }
}

if (!function_exists('validarEmail')) {
    function validarEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

if (!function_exists('esc')) {
    function esc(?string $texto): string {
        return htmlspecialchars((string)$texto, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('formatarDataBR')) {
    function formatarDataBR(?string $data): string {
        if (empty($data)) return '';
        try { return (new DateTime($data))->format('d/m/Y'); }
        catch (Exception $e) { return $data; }
    }
}

if (!function_exists('formatarDataHoraBR')) {
    function formatarDataHoraBR(?string $data): string {
        if (empty($data)) return '';
        try { return (new DateTime($data))->format('d/m/Y H:i'); }
        catch (Exception $e) { return $data; }
    }
}

// ---------------- ENTRADA SEGURA ----------------
if (!function_exists('inputTexto')) {
    // Lê um parâmetro de texto de $_GET/$_POST. Se vier como array (?q[]=x), devolve o padrão:
    // trim()/mb_substr() com array lançam TypeError no PHP 8 (erro 500).
    function inputTexto(array $origem, string $chave, string $padrao = ''): string
    {
        $v = $origem[$chave] ?? $padrao;
        return is_string($v) ? trim($v) : $padrao;
    }
}

if (!function_exists('validarSenhaForte')) {
    // Política única de senha (cadastro, perfil, recuperação e funcionários).
    // Devolve a mensagem do primeiro problema, ou null se a senha é válida.
    function validarSenhaForte(string $senha): ?string
    {
        if (strlen($senha) < 8)                    return 'A senha deve ter pelo menos 8 caracteres.';
        if (!preg_match('/[A-Z]/', $senha))        return 'A senha deve ter pelo menos 1 letra MAIÚSCULA.';
        if (!preg_match('/[a-z]/', $senha))        return 'A senha deve ter pelo menos 1 letra minúscula.';
        if (!preg_match('/[0-9]/', $senha))        return 'A senha deve ter pelo menos 1 número.';
        if (!preg_match('/[^A-Za-z0-9]/', $senha)) return 'A senha deve ter pelo menos 1 caractere especial (!@#$…).';
        return null;
    }
}

if (!function_exists('paginaErroHtml')) {
    // Página de erro estilizada para formulários HTML nativos (o navegador não deve mostrar JSON cru).
    function paginaErroHtml(string $titulo, string $mensagem, int $httpCode = 400): void
    {
        http_response_code($httpCode);
        header('Content-Type: text/html; charset=utf-8');
        $t = htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8');
        $m = htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8');
        echo "<!DOCTYPE html><html lang='pt-br'><head><meta charset='UTF-8'>"
           . "<meta name='viewport' content='width=device-width, initial-scale=1.0'><title>{$t} - DWS</title>"
           . "<style>*{margin:0;padding:0;box-sizing:border-box}"
           . "body{background:linear-gradient(135deg,#1e1e1e,#3b3b3b);display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px;font-family:'Segoe UI',Arial,sans-serif}"
           . ".box{background:#403E3F;padding:40px;border-radius:25px;text-align:center;border:1px solid #F23535;max-width:420px;width:100%}"
           . ".ico{width:90px;height:90px;background:#F23535;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:46px;color:#fff}"
           . "h1{color:#fff;margin-bottom:15px;font-size:1.4rem}p{color:#ccc;margin-bottom:10px;line-height:1.5}"
           . "button{background:#F23535;color:#fff;border:none;padding:12px 30px;border-radius:30px;font-size:16px;cursor:pointer;margin-top:20px}</style></head>"
           . "<body><div class='box'><div class='ico'>&#10007;</div><h1>{$t}</h1><p>{$m}</p>"
           . "<button onclick='window.history.back()'>Voltar e corrigir</button></div></body></html>";
        exit;
    }
}

// ---------------- FUNCIONÁRIOS: coluna de e-mail ----------------
if (!function_exists('garantirColunaEmailFuncionario')) {
    // Cria funcionarios.email se ainda não existir (necessário para recuperar senha do ADM)
    function garantirColunaEmailFuncionario(PDO $pdo): void
    {
        try {
            if (!$pdo->query("SHOW COLUMNS FROM funcionarios LIKE 'email'")->fetch()) {
                $pdo->exec("ALTER TABLE funcionarios ADD COLUMN email VARCHAR(150) NULL");
            }
        } catch (PDOException $e) {
            error_log('[funcionarios.email] ' . $e->getMessage());
        }
    }
}

if (!function_exists('mascararEmail')) {
    // joao.silva@gmail.com → j***@gmail.com
    function mascararEmail(string $email): string
    {
        [$u, $d] = array_pad(explode('@', $email, 2), 2, '');
        $ini = mb_substr($u, 0, 1);
        return $ini . str_repeat('*', max(3, min(6, mb_strlen($u) - 1))) . '@' . $d;
    }
}

// ---------------- E-MAIL ----------------
if (!function_exists('configEmail')) {
    // Config de e-mail = bloco 'email' do config.php + (se existir) PHP/Config/email.local.php,
    // arquivo gerado pela página configurar_email.php (uso em site local).
    function configEmail(): array
    {
        $cfg = (array) config('email', []);
        $local = __DIR__ . '/Config/email.local.php';
        if (is_readable($local)) {
            $extra = require $local;
            if (is_array($extra)) $cfg = array_merge($cfg, $extra);
        }
        return $cfg;
    }
}

if (!function_exists('enviarEmail')) {
    // Envia e-mail HTML via SMTP (config 'email') ou, sem host configurado, via mail() do servidor.
    function enviarEmail(string $para, string $nome, string $assunto, string $html, string $texto = ''): bool
    {
        require_once __DIR__ . '/lib/PHPMailer/Exception.php';
        require_once __DIR__ . '/lib/PHPMailer/PHPMailer.php';
        require_once __DIR__ . '/lib/PHPMailer/SMTP.php';

        $cfg = configEmail();
        $GLOBALS['dws_erro_email'] = '';
        if (empty($cfg['host']) && empty($cfg['de_email']) && empty($cfg['usuario'])) {
            $GLOBALS['dws_erro_email'] = 'E-mail não configurado. No site local, abra PHP/Config/configurar_email.php; em hospedagem, preencha o bloco "email" do config.php.';
            error_log('[EMAIL] ' . $GLOBALS['dws_erro_email']);
            return false;
        }
        try {
            $m = new \PHPMailer\PHPMailer\PHPMailer(true);
            $m->CharSet = 'UTF-8';
            if (!empty($cfg['host'])) {
                $m->isSMTP();
                $m->Host       = $cfg['host'];
                $m->Port       = (int) ($cfg['port'] ?? 587);
                $m->SMTPAuth   = !empty($cfg['usuario']);
                $m->Username   = (string) ($cfg['usuario'] ?? '');
                $m->Password   = (string) ($cfg['senha'] ?? '');
                $seg = (string) ($cfg['seguranca'] ?? 'tls');
                $m->SMTPSecure = $seg === 'ssl' ? 'ssl' : ($seg === 'tls' ? 'tls' : '');
                $m->SMTPAutoTLS = $seg !== '';
                $m->Timeout    = 15;
                // Em XAMPP/Windows o certificado SSL costuma falhar: 'verificar_ssl' => false resolve em testes
                if (isset($cfg['verificar_ssl']) && $cfg['verificar_ssl'] === false) {
                    $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
                }
            } else {
                $m->isMail();
            }
            $de = (string) ($cfg['de_email'] ?? ($cfg['usuario'] ?? 'nao-responda@localhost'));
            $m->setFrom($de, (string) ($cfg['de_nome'] ?? 'DWS Envelopamento'));
            $m->addAddress($para, $nome);
            $m->isHTML(true);
            $m->Subject = $assunto;
            $m->Body    = $html;
            $m->AltBody = $texto !== '' ? $texto : trim(strip_tags($html));
            $m->send();
            return true;
        } catch (\Throwable $e) {
            $GLOBALS['dws_erro_email'] = $e->getMessage();
            error_log('[EMAIL] falha ao enviar: ' . $e->getMessage());
            return false;
        }
    }
}

// ---------------- PAGAMENTO (modo teste) ----------------
if (!function_exists('pagamentoModoTeste')) {
    // Simulado quando mp.modo_teste = true OU quando o token do Mercado Pago não foi configurado
    function pagamentoModoTeste(): bool
    {
        if (config('mp.modo_teste', false)) return true;
        $t = (string) config('mp.access_token', '');
        return $t === '' || $t === 'COLE_AQUI_O_NOVO_TOKEN';
    }
}

// ---------------- AGENDA ----------------
if (!function_exists('sqlAgendamentoAtivo')) {
    // Condição SQL de "agendamento que ocupa o dia".
    // Online não pago expira após config('agenda.expira_pendente_horas').
    function sqlAgendamentoAtivo(string $alias = '', bool $considerarCancelado = true): string
    {
        $a = $alias !== '' ? $alias . '.' : '';
        $h = max(1, (int) config('agenda.expira_pendente_horas', 24));
        // IFNULL: status NULL não pode "liberar" o dia (NULL NOT IN (...) avalia como NULL, não como verdadeiro)
        $sql = "IFNULL({$a}serstatus_pagamento, 'pendente') NOT IN ('cancelado', 'rejeitado', 'estornado', 'expirado')"
             . " AND NOT (IFNULL({$a}serstatus_pagamento, 'pendente') = 'pendente'"
             . " AND IFNULL({$a}sercriado_em, NOW()) < (NOW() - INTERVAL {$h} HOUR))";
        // Pedido cancelado pelo ADM (status do serviço) libera a data para outro cliente
        if ($considerarCancelado) {
            $sql .= " AND IFNULL({$a}serstatus_servico, '') <> 'cancelado'";
        }
        return $sql;
    }
}

if (!function_exists('intervaloDia')) {
    // [início, fim) de um dia 'Y-m-d' para usar com índice em serdata_servico
    function intervaloDia(string $data): array
    {
        $ini = new DateTime($data . ' 00:00:00');
        $fim = (clone $ini)->modify('+1 day');
        return [$ini->format('Y-m-d H:i:s'), $fim->format('Y-m-d H:i:s')];
    }
}

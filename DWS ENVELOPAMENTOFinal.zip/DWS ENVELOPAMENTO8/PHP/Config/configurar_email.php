<?php
// =====================================================
// configurar_email.php — Configura o envio de e-mail do site LOCAL (XAMPP)
// Só abre no próprio computador (127.0.0.1 / ::1). Digite o Gmail + senha de app,
// o sistema envia um e-mail de TESTE e, se chegar, salva em PHP/Config/email.local.php.
// Depois disso o "Esqueci minha senha" passa a enviar e-mails de verdade.
// Acesse: http://localhost/SUA_PASTA/PHP/Config/configurar_email.php
// =====================================================
require_once __DIR__ . '/../bootstrap.php';

$ipRemoto = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ipRemoto, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Esta página só abre no computador onde o site está instalado (localhost).');
}
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');

$arquivoLocal = __DIR__ . '/email.local.php';
$provedores = [
    'gmail'   => ['Gmail',           'smtp.gmail.com',          587, 'tls'],
    'outlook' => ['Outlook/Hotmail', 'smtp-mail.outlook.com',   587, 'tls'],
    'brevo'   => ['Brevo',           'smtp-relay.brevo.com',    587, 'tls'],
    'outro'   => ['Outro (manual)',  '',                        587, 'tls'],
];
function h($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

/** Esconde credenciais (base64) do log SMTP */
function limparLog(string $log): string
{
    $log = preg_replace('/(CLIENT -> SERVER: )[A-Za-z0-9+\/=]{12,}\s*$/m', '$1[credencial oculta]', $log);
    return preg_replace('/(AUTH (?:PLAIN|LOGIN|XOAUTH2)) \S+/i', '$1 [oculto]', $log);
}

/** Envia um e-mail de teste; devolve [ok, log, erro] */
function enviarTeste(array $cfg, string $para): array
{
    require_once __DIR__ . '/../lib/PHPMailer/Exception.php';
    require_once __DIR__ . '/../lib/PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/../lib/PHPMailer/SMTP.php';
    $log = '';
    try {
        $m = new \PHPMailer\PHPMailer\PHPMailer(true);
        $m->CharSet = 'UTF-8';
        $m->SMTPDebug = 2;
        $m->Debugoutput = function ($s) use (&$log) { $log .= trim($s) . "\n"; };
        $m->isSMTP();
        $m->Host = $cfg['host'];
        $m->Port = (int) $cfg['port'];
        $m->SMTPAuth = $cfg['usuario'] !== '';
        $m->Username = $cfg['usuario'];
        $m->Password = $cfg['senha'];
        $m->SMTPSecure = $cfg['seguranca'] === 'ssl' ? 'ssl' : ($cfg['seguranca'] === 'tls' ? 'tls' : '');
        $m->SMTPAutoTLS = $cfg['seguranca'] !== '';
        $m->Timeout = 15;
        if (($cfg['verificar_ssl'] ?? true) === false) {
            $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        }
        $m->setFrom($cfg['de_email'], $cfg['de_nome']);
        $m->addAddress($para);
        $m->Subject = 'Teste de e-mail — DWS Envelopamento';
        $m->isHTML(true);
        $m->Body = '<p>✅ Se você recebeu este e-mail, o envio está funcionando. O "Esqueci minha senha" já pode enviar códigos.</p>';
        $m->AltBody = 'Se você recebeu este e-mail, o envio está funcionando.';
        $m->send();
        return [true, limparLog($log), ''];
    } catch (\Throwable $e) {
        return [false, limparLog($log), $e->getMessage()];
    }
}

function dica(string $erro): string
{
    $e = strtolower($erro);
    if (strpos($e, '535') !== false || strpos($e, 'username and password not accepted') !== false || strpos($e, 'authenticate') !== false) {
        return 'Usuário ou senha recusados. No Gmail use uma SENHA DE APP de 16 letras (não a senha normal) e ative a verificação em duas etapas.';
    }
    if (strpos($e, 'could not connect') !== false || strpos($e, 'connection') !== false) {
        return 'Não conectou ao servidor. Verifique a internet, se o antivírus/firewall bloqueia a porta 587, e se "extension=openssl" está ativo no php.ini do XAMPP.';
    }
    if (strpos($e, 'certificate') !== false || strpos($e, 'ssl') !== false) {
        return 'Problema de certificado SSL do XAMPP. O sistema já tenta de novo sem validar o certificado.';
    }
    return 'Confira os dados e o log abaixo.';
}

$msg = ''; $tipo = ''; $log = '';
$acao = $_POST['acao'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validarTokenCSRF($_POST['csrf_token'] ?? null)) {
        $msg = 'Sessão expirada. Recarregue a página.'; $tipo = 'erro';
    } elseif ($acao === 'remover') {
        if (is_file($arquivoLocal)) unlink($arquivoLocal);
        $msg = 'Configuração salva removida.'; $tipo = 'ok';
    } elseif ($acao === 'salvar') {
        $prov = $_POST['provedor'] ?? 'gmail';
        if (!isset($provedores[$prov])) $prov = 'outro';
        $usuario = trim((string) ($_POST['usuario'] ?? ''));
        $senha   = preg_replace('/\s+/', '', (string) ($_POST['senha'] ?? '')); // senha de app vem com espaços
        $para    = trim((string) ($_POST['para'] ?? '')) ?: $usuario;
        $host    = $prov === 'outro' ? trim((string) ($_POST['host'] ?? '')) : $provedores[$prov][1];
        $port    = $prov === 'outro' ? (int) ($_POST['port'] ?? 587) : $provedores[$prov][2];
        $seg     = $prov === 'outro' ? (string) ($_POST['seguranca'] ?? 'tls') : $provedores[$prov][3];
        if (!in_array($seg, ['tls', 'ssl', ''], true)) $seg = 'tls';

        if ($host === '' || $usuario === '' || $senha === '') {
            $msg = 'Preencha servidor, e-mail e senha.'; $tipo = 'erro';
        } elseif (!validarEmail($para)) {
            $msg = 'E-mail de destino do teste inválido.'; $tipo = 'erro';
        } else {
            $cfg = [
                'host' => $host, 'port' => $port, 'seguranca' => $seg,
                'usuario' => $usuario, 'senha' => $senha,
                'de_email' => $usuario, 'de_nome' => trim((string) ($_POST['de_nome'] ?? '')) ?: 'DWS Envelopamento',
                'verificar_ssl' => true,
            ];
            [$ok, $log, $erro] = enviarTeste($cfg, $para);
            if (!$ok && (stripos($erro, 'certificate') !== false || stripos($erro, 'ssl') !== false || stripos($erro, 'crypto') !== false)) {
                $cfg['verificar_ssl'] = false; // XAMPP/Windows costuma não ter os certificados
                [$ok, $log, $erro] = enviarTeste($cfg, $para);
            }
            if ($ok) {
                $php = "<?php\n// Gerado por configurar_email.php — contém senha. NÃO envie para o GitHub nem compartilhe.\nreturn " . var_export($cfg, true) . ";\n";
                if (file_put_contents($arquivoLocal, $php, LOCK_EX) === false) {
                    $msg = 'O e-mail de teste foi enviado, mas não consegui salvar em PHP/Config/email.local.php (sem permissão de escrita).'; $tipo = 'erro';
                } else {
                    @chmod($arquivoLocal, 0600);
                    $msg = "✅ E-mail de teste ENVIADO para {$para} (veja também o spam) e configuração SALVA. O \"Esqueci minha senha\" já envia e-mails de verdade."; $tipo = 'ok';
                }
            } else {
                $msg = '❌ Falhou: ' . $erro . ' — ' . dica($erro); $tipo = 'erro';
            }
        }
    }
}

$salvo = is_readable($arquivoLocal) ? (array) require $arquivoLocal : [];
$token = gerarTokenCSRF();
?>
<!DOCTYPE html>
<html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configurar e-mail (local)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;background:#0b0b0b;color:#eee;margin:0;padding:24px}
.box{max-width:560px;margin:auto;background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:26px}
h1{font-size:1.2rem;margin:0 0 4px}small,.sub{color:#999}label{display:block;margin:14px 0 5px;font-size:.85rem;color:#bbb}
input,select{width:100%;padding:12px;background:#0b0b0b;border:2px solid #2a2a2a;border-radius:10px;color:#fff;font:inherit;box-sizing:border-box}
input:focus,select:focus{outline:0;border-color:#f23535}
button{padding:13px;border:0;border-radius:10px;font:inherit;font-weight:700;cursor:pointer;width:100%;margin-top:18px;background:linear-gradient(135deg,#f23535,#c91f2c);color:#fff}
button.sec{background:#2a2a2a;color:#ccc;margin-top:10px}
.msg{padding:12px;border-radius:10px;margin:14px 0;font-size:.9rem;line-height:1.45}
.ok{background:#25d36618;border:1px solid #25d36655;color:#25d366}.erro{background:#f2353518;border:1px solid #f2353555;color:#ff8080}
pre{background:#0b0b0b;border:1px solid #2a2a2a;border-radius:10px;padding:10px;font-size:.72rem;max-height:240px;overflow:auto;white-space:pre-wrap;color:#aaa}
ol{color:#bbb;font-size:.85rem;line-height:1.6;padding-left:20px}.manual{display:none}
</style></head><body><div class="box">
<h1>📧 Configurar envio de e-mail</h1>
<div class="sub">Site local — faz o código do "Esqueci minha senha" chegar no e-mail de verdade.</div>

<?php if ($msg): ?><div class="msg <?= $tipo ?>"><?= h($msg) ?></div><?php endif; ?>
<?php if ($salvo && $tipo !== 'ok'): ?>
  <div class="msg ok">Configuração salva: <b><?= h($salvo['usuario'] ?? '') ?></b> via <?= h($salvo['host'] ?? '') ?>.</div>
<?php endif; ?>

<ol>
  <li>Na conta Google que vai <b>enviar</b>: ative a <b>verificação em duas etapas</b>.</li>
  <li>Em <i>Segurança → Senhas de app</i>, crie uma e copie as 16 letras.</li>
  <li>Preencha abaixo e clique em <b>Enviar teste e salvar</b>.</li>
</ol>

<form method="post" autocomplete="off">
  <input type="hidden" name="csrf_token" value="<?= h($token) ?>">
  <input type="hidden" name="acao" value="salvar">
  <label>Provedor</label>
  <select name="provedor" id="prov">
    <?php foreach ($provedores as $k => $v): ?><option value="<?= $k ?>" <?= (($_POST['provedor'] ?? 'gmail') === $k) ? 'selected' : '' ?>><?= h($v[0]) ?></option><?php endforeach; ?>
  </select>
  <div class="manual" id="manual">
    <label>Servidor SMTP</label><input name="host" placeholder="smtp.seuprovedor.com" value="<?= h($_POST['host'] ?? '') ?>">
    <label>Porta</label><input name="port" type="number" value="<?= h($_POST['port'] ?? 587) ?>">
    <label>Segurança</label><select name="seguranca"><option value="tls">TLS (587)</option><option value="ssl">SSL (465)</option><option value="">Nenhuma</option></select>
  </div>
  <label>E-mail que envia (remetente)</label>
  <input type="email" name="usuario" placeholder="seuemail@gmail.com" value="<?= h($_POST['usuario'] ?? ($salvo['usuario'] ?? '')) ?>" required>
  <label>Senha de app (16 letras — NÃO é a senha normal)</label>
  <input type="password" name="senha" placeholder="abcd efgh ijkl mnop" autocomplete="new-password" required>
  <label>Nome do remetente</label>
  <input name="de_nome" value="<?= h($_POST['de_nome'] ?? ($salvo['de_nome'] ?? 'DWS Envelopamento')) ?>">
  <label>Enviar o teste para <small>(vazio = o próprio e-mail acima)</small></label>
  <input type="email" name="para" placeholder="onde você quer receber o teste" value="<?= h($_POST['para'] ?? '') ?>">
  <button type="submit">Enviar teste e salvar</button>
</form>
<?php if ($salvo): ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= h($token) ?>"><input type="hidden" name="acao" value="remover">
  <button class="sec" type="submit">Remover configuração salva</button></form>
<?php endif; ?>

<?php if ($log): ?><label>Log da conexão (senha oculta)</label><pre><?= h($log) ?></pre><?php endif; ?>
<p><small>A senha fica no arquivo <code>PHP/Config/email.local.php</code> (bloqueado no servidor). Não envie esse arquivo para ninguém. Em produção (hospedagem), preencha o bloco <code>email</code> do <code>config.php</code>.</small></p>
</div>
<script>
const p=document.getElementById('prov'),m=document.getElementById('manual');
function t(){m.style.display=p.value==='outro'?'block':'none'}p.onchange=t;t();
</script>
<script src="../../js/toggle-senha.js" defer></script>
</body></html>

<?php
// =====================================================================
// MODELO PARA INFINITYFREE — copie este arquivo para  config.php  (mesma pasta)
// e troque os 3 valores marcados com >>> . Pegue-os no painel (Client Area >
// sua conta if0_43534606 > "MySQL Databases").
// =====================================================================
return [
    'db' => [
        'host'    => 'sqlXXX.infinityfree.com',     // >>> "MySQL Host Name" do painel (NÃO é localhost)
        'port'    => 3306,
        'name'    => 'if0_43534606_dws',            // >>> nome COMPLETO do banco (com o prefixo if0_...)
        'user'    => 'if0_43534606',                // usuário do MySQL (normalmente igual à conta)
        'pass'    => 'COLE_A_SENHA_DO_PAINEL',      // >>> senha do vPanel/MySQL
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'env'      => 'production',
        'debug'    => false,                        // mude p/ true só 1 minuto, se precisar ver o erro de conexão
        'url'      => 'https://dwsenvelopamento.infinityfreeapp.com',
        'timezone' => 'America/Sao_Paulo',
        'session_name'     => 'DWSSESSID',
        'session_lifetime' => 7200,
    ],
    'admin'   => ['super_admin_ids' => [1]],
    'agenda'  => ['expira_pendente_horas' => 24],
    'contato' => ['whatsapp' => '5514996175617'],
    'mp' => [
        'modo_teste'     => true,                   // pagamento SIMULADO (sem Mercado Pago)
        'ambiente'       => 'sandbox',
        'access_token'   => 'COLE_AQUI_O_NOVO_TOKEN',
        'webhook_secret' => 'COLE_AQUI_O_NOVO_SECRET',
    ],
    'email' => [
        'host' => '', 'port' => 587, 'seguranca' => 'tls', 'usuario' => '', 'senha' => '',
        'de_email' => '', 'de_nome' => 'DWS Envelopamento', 'verificar_ssl' => true,
    ],
];

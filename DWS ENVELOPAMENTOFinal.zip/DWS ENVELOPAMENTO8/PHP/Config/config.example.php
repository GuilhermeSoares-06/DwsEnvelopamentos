<?php
// =============================================
// config.php — Configurações centralizadas
// Modelo: copie para config.php e preencha. config.php não vai para o Git.
// =============================================
return [
    'db' => [
        'host'    => 'localhost',
        'port'    => 3306,
        'name'    => 'dws',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],

    'app' => [
        'env'      => 'production',          // 'development' | 'production'
        'debug'    => false,                    // false em produção
        'url'      => 'https://seudominio.com.br',  // URL base (sem barra no final)
        'timezone' => 'America/Sao_Paulo',
        'session_name' => 'DWSSESSID',
        'session_lifetime' => 7200,            // 2h
    ],

    'admin' => [
        // IDs da tabela `funcionarios` que podem ver o Faturamento
        'super_admin_ids' => [1],
    ],

    'agenda' => [
        // Agendamento online não pago libera o dia após X horas
        'expira_pendente_horas' => 24,
    ],

    'contato' => [
        // Recebe o aviso de novo agendamento (somente dígitos, com DDI)
        'whatsapp' => '5514996175617',
    ],

    'mp' => [
        // true = pagamento SIMULADO (tela de teste, sem Mercado Pago). Use false em produção.
        'modo_teste'     => true,
        'ambiente'       => 'sandbox',         // 'sandbox' | 'production'
        'access_token'   => 'COLE_AQUI_O_NOVO_TOKEN',
        'webhook_secret' => 'COLE_AQUI_O_NOVO_SECRET',
    ],
    'email' => [
        // SMTP para enviar o código de "esqueci minha senha". Deixe 'host' vazio para usar mail() do servidor.
        'host'      => '',                       // ex.: smtp.gmail.com
        'port'      => 587,
        'seguranca' => 'tls',                    // 'tls' (587) | 'ssl' (465) | ''
        'usuario'   => '',                       // ex.: seuemail@gmail.com
        'senha'     => '',                       // senha de app (não a senha normal)
        'de_email'  => '',                       // remetente (normalmente igual ao usuário)
        'de_nome'   => 'DWS Envelopamento',
        'verificar_ssl' => true,                 // use false só se der erro de certificado no XAMPP/Windows
    ],
];
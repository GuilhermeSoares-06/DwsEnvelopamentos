<?php
// =============================================
// testar_email.php — Diagnóstico do envio de e-mail (somente ADM logado)
// Acesse: /PHP/Config/testar_email.php?para=seuemail@dominio.com
// Mostra o diálogo SMTP completo e o motivo exato da falha.
// APAGUE este arquivo depois de configurar.
// =============================================
require_once __DIR__ . '/../bootstrap.php';
exigirAdminApi();

header('Content-Type: text/plain; charset=utf-8');

$para = trim((string) ($_GET['para'] ?? ''));
if (!validarEmail($para)) {
    exit("Informe o destino: testar_email.php?para=seuemail@dominio.com\n");
}

$cfg = configEmail();
echo "Host: " . ($cfg['host'] ?? '(vazio → usa mail() do servidor, que NÃO funciona no XAMPP/Windows)') . "\n";
echo "Porta: " . ($cfg['port'] ?? '-') . " | Segurança: " . ($cfg['seguranca'] ?? '-') . " | Usuário: " . ($cfg['usuario'] ?? '(vazio)') . "\n";
echo "Senha preenchida: " . (!empty($cfg['senha']) ? 'sim' : 'NÃO') . "\n\n";

require_once __DIR__ . '/../lib/PHPMailer/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/SMTP.php';

try {
    $m = new \PHPMailer\PHPMailer\PHPMailer(true);
    $m->CharSet = 'UTF-8';
    $m->SMTPDebug  = 2;
    $m->Debugoutput = function ($s) {
        // oculta usuário/senha (base64) do diálogo AUTH
        $s = preg_replace('/(CLIENT -> SERVER: )[A-Za-z0-9+\/=]{12,}\s*$/m', '$1[credencial oculta]', trim($s));
        $s = preg_replace('/(AUTH (?:PLAIN|LOGIN|XOAUTH2)) \S+/i', '$1 [oculto]', $s);
        echo $s . "\n";
    };
    if (!empty($cfg['host'])) {
        $m->isSMTP();
        $m->Host = $cfg['host'];
        $m->Port = (int) ($cfg['port'] ?? 587);
        $m->SMTPAuth = !empty($cfg['usuario']);
        $m->Username = (string) ($cfg['usuario'] ?? '');
        $m->Password = (string) ($cfg['senha'] ?? '');
        $seg = (string) ($cfg['seguranca'] ?? 'tls');
        $m->SMTPSecure = $seg === 'ssl' ? 'ssl' : ($seg === 'tls' ? 'tls' : '');
        $m->Timeout = 15;
        if (isset($cfg['verificar_ssl']) && $cfg['verificar_ssl'] === false) {
            $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        }
    } else {
        $m->isMail();
    }
    $m->setFrom((string) ($cfg['de_email'] ?? ($cfg['usuario'] ?? 'teste@localhost')), 'DWS Envelopamento');
    $m->addAddress($para);
    $m->Subject = 'Teste de e-mail DWS';
    $m->Body = 'Se você recebeu isto, o envio de e-mail está funcionando.';
    $m->send();
    echo "\n✅ ENVIADO com sucesso para $para (confira também o spam)\n";
} catch (\Throwable $e) {
    echo "\n❌ FALHOU: " . $e->getMessage() . "\n";
}

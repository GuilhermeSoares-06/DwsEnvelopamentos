<?php
// =============================================
// simular_pagamento.php — Resultado do pagamento SIMULADO (modo teste)
// POST: servico_id, metodo = pix|cartao|local, resultado = ok|pend|rej
// Só funciona com mp.modo_teste = true (ou sem token do MP configurado).
// =============================================
require_once __DIR__ . '/../bootstrap.php';
enviarHeadersSeguranca(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responderErro('Método não permitido.', 405);
if (!pagamentoModoTeste()) responderErro('Pagamento simulado desativado.', 403);
exigirLoginCliente();
exigirCSRF();

$cliid = (int) $_SESSION['cliid'];
$serid = (int) ($_POST['servico_id'] ?? 0);
$metodo = $_POST['metodo'] ?? '';
$res = $_POST['resultado'] ?? 'ok';
if ($serid <= 0 || !in_array($metodo, ['pix', 'cartao', 'local'], true)) responderErro('Dados inválidos.');

try {
    // "ativo" = mesma regra que ocupa o dia na agenda (não expirado, não cancelado).
    // Sem isso, um pedido expirado/cancelado cujo dia já foi dado a outro cliente podia ser
    // "pago" e gerar DOIS agendamentos ativos no mesmo dia.
    $st = $pdo->prepare("
        SELECT serstatus_pagamento, (" . sqlAgendamentoAtivo() . ") AS ativo
        FROM servicos WHERE serid = :s AND cliid = :c LIMIT 1
    ");
    $st->execute([':s' => $serid, ':c' => $cliid]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) responderErro('Agendamento não encontrado.', 404);
    $atual = $row['serstatus_pagamento'];
    if ($atual === 'aprovado') responderErro('Este agendamento já está pago.', 409);
    if (!(int) $row['ativo']) responderErro('Este agendamento expirou ou foi cancelado. Faça um novo agendamento.', 409);

    if ($metodo === 'local') {
        $novo = 'pagar_no_local';
    } else {
        $novo = ['ok' => 'aprovado', 'pend' => 'pendente', 'rej' => 'rejeitado'][$res] ?? 'pendente';
    }

    $pdo->prepare("UPDATE servicos SET serstatus_pagamento = :s,
            sermp_metodo_pagamento = :m,
            serdata_pagamento = " . ($novo === 'aprovado' ? 'NOW()' : 'NULL') . "
        WHERE serid = :id AND cliid = :c")
        ->execute([':s' => $novo, ':m' => $metodo === 'local' ? null : $metodo, ':id' => $serid, ':c' => $cliid]);

    logAuditoria('pagamento_simulado', ['serid' => $serid, 'status' => $novo, 'metodo' => $metodo]);
    responderSucesso('Simulado.', ['pagamento' => $novo]);
} catch (PDOException $e) {
    error_log('[simular_pagamento] ' . $e->getMessage());
    responderErro('Erro interno.', 500);
}

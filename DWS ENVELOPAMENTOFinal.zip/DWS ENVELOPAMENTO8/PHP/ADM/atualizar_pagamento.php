<?php
// =============================================
// atualizar_pagamento.php — ADM marca o pagamento de um pedido
// POST: id, acao = pago | pagar_no_local | pendente
//       metodo (só para "pago"): dinheiro | pix | cartao | outro
// Resposta JSON. Exige admin logado + token CSRF (header X-CSRF-Token).
// =============================================
require_once __DIR__ . '/../bootstrap.php';

enviarHeadersSeguranca(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responderErro('Método não permitido.', 405);
}

exigirAdminApi();
exigirCSRF();

$id     = (int) ($_POST['id'] ?? 0);
$acao   = trim((string) ($_POST['acao'] ?? ''));
$metodo = trim((string) ($_POST['metodo'] ?? ''));

if ($id <= 0) responderErro('Pedido inválido.');

$mapa = [
    'pago'           => 'aprovado',
    'pagar_no_local' => 'pagar_no_local',
    'pendente'       => 'pendente',
];
if (!isset($mapa[$acao])) responderErro('Ação inválida.');
$novoStatus = $mapa[$acao];

$metodosOk = ['dinheiro', 'pix', 'cartao', 'outro'];
if ($acao === 'pago' && !in_array($metodo, $metodosOk, true)) {
    $metodo = 'outro';
}

try {
    $stmt = $pdo->prepare("
        SELECT serid, serdata_servico, serstatus_pagamento, sermp_metodo_pagamento, servalor
        FROM servicos WHERE serid = :id LIMIT 1
    ");
    $stmt->execute([':id' => $id]);
    $ped = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$ped) responderErro('Pedido não encontrado.', 404);

    $statusAntes = (string) $ped['serstatus_pagamento'];

    // Reativar um pedido que já tinha liberado o dia (cancelado/expirado)
    // não pode gerar dois agendamentos no mesmo dia.
    if (in_array($novoStatus, ['aprovado', 'pagar_no_local'], true)
        && !in_array($statusAntes, ['aprovado', 'pagar_no_local'], true)) {
        [$ini, $fim] = intervaloDia(date('Y-m-d', strtotime($ped['serdata_servico'])));
        $c = $pdo->prepare("
            SELECT COUNT(*) FROM servicos
            WHERE serid <> :id AND serdata_servico >= :ini AND serdata_servico < :fim
              AND " . sqlAgendamentoAtivo());
        $c->execute([':id' => $id, ':ini' => $ini, ':fim' => $fim]);
        if ((int) $c->fetchColumn() > 0) {
            responderErro('Esse dia já foi ocupado por outro agendamento. Não é possível reativar este pedido.', 409);
        }
    }

    if ($acao === 'pago') {
        $upd = $pdo->prepare("
            UPDATE servicos
            SET serstatus_pagamento = 'aprovado',
                sermp_metodo_pagamento = :m,
                serdata_pagamento = NOW()
            WHERE serid = :id");
        $upd->execute([':m' => $metodo, ':id' => $id]);
    } else {
        // voltou para "a receber" / "aguardando": limpa método e data do pagamento
        $upd = $pdo->prepare("
            UPDATE servicos
            SET serstatus_pagamento = :s,
                sermp_metodo_pagamento = NULL,
                serdata_pagamento = NULL
            WHERE serid = :id");
        $upd->execute([':s' => $novoStatus, ':id' => $id]);
    }

    logAuditoria('admin_alterar_pagamento', [
        'admin'  => $_SESSION['admin_id'] ?? null,
        'serid'  => $id,
        'de'     => $statusAntes,
        'para'   => $novoStatus,
        'metodo' => $acao === 'pago' ? $metodo : null,
    ]);

    responderSucesso('Pagamento atualizado.', [
        'serid'  => $id,
        'pagamento' => $novoStatus,
        'metodo' => $acao === 'pago' ? $metodo : null,
    ]);

} catch (PDOException $e) {
    error_log('[atualizar_pagamento] ' . $e->getMessage());
    responderErro('Erro ao atualizar o pagamento.', 500);
}

<?php
// =============================================
// diagnostico_login.php — Descobre por que o login do ADM não cria sessão
// SÓ funciona com 'app' => ['env' => 'development'] no config.php.
// Acesse: /PHP/ADM/diagnostico_login.php   (APAGUE depois de resolver)
// =============================================
require_once __DIR__ . '/../bootstrap.php';

if (APP_ENV !== 'development' || !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)) { http_response_code(404); exit; }
header('Content-Type: text/html; charset=utf-8');

function linha($ok, $txt) { echo ($ok === null ? '➖' : ($ok ? '✅' : '❌')) . ' ' . htmlspecialchars($txt) . "\n"; }

$chaveRL = 'login_adm_' . ipCliente();
echo "<!DOCTYPE html><meta charset='utf-8'><title>Diagnóstico login ADM</title><body style='font-family:monospace;background:#111;color:#eee;padding:20px'><pre style='white-space:pre-wrap'>";
echo "=== DIAGNÓSTICO DO LOGIN ADM ===\n\n";

// 1) Ambiente
linha(is_readable(__DIR__ . '/../Config/config.php'), 'config.php existe e é legível (se ❌, o site usa valores padrão!)');
linha(null, 'PHP ' . PHP_VERSION . ' | env=' . APP_ENV . ' | host=' . ($_SERVER['HTTP_HOST'] ?? '?'));
$sp = session_save_path() ?: sys_get_temp_dir();
linha(is_writable($sp), "Pasta de sessões gravável: $sp");
$cp = session_get_cookie_params();
linha(null, 'Cookie de sessão: nome=' . session_name() . ' secure=' . var_export($cp['secure'], true) . ' samesite=' . ($cp['samesite'] ?? '-') . ' path=' . $cp['path']);

// 2) Persistência da sessão (recarregue a página para confirmar)
if (!isset($_SESSION['diag_ts'])) {
    $_SESSION['diag_ts'] = time();
    linha(null, 'Sessão nova criada agora. RECARREGUE esta página (F5): se aparecer ❌ de novo, o navegador/servidor NÃO está guardando a sessão.');
} else {
    linha(true, 'Sessão persistiu entre duas requisições (criada há ' . (time() - $_SESSION['diag_ts']) . 's). Cookies/sessão OK.');
}

// 3) Banco
try {
    $n = (int) $pdo->query("SELECT COUNT(*) FROM funcionarios")->fetchColumn();
    linha(true, "Banco conectado. Funcionários cadastrados: $n");
} catch (Throwable $e) {
    linha(false, 'Erro no banco / tabela funcionarios: ' . $e->getMessage());
}

// 4) Bloqueio por tentativas
try {
    if (rateLimitPdo()) {
        $q = $pdo->prepare("SELECT COUNT(*) FROM tentativas_login WHERE chave = :c");
        $q->execute([':c' => md5($chaveRL)]);
        $t = (int) $q->fetchColumn();
    } else {
        $t = count($_SESSION['rl_' . md5($chaveRL)] ?? []);
    }
    linha($t < 5, "Tentativas de login registradas para o seu IP (" . ipCliente() . "): $t/5" . ($t >= 5 ? '  → VOCÊ ESTÁ BLOQUEADO por 15 min' : ''));
} catch (Throwable $e) { linha(null, 'Não foi possível ler tentativas: ' . $e->getMessage()); }

if (($_POST['acao'] ?? '') === 'limpar') {
    limparTentativas($chaveRL);
    linha(true, 'Bloqueio de tentativas LIMPO para o seu IP.');
}

// 5) Teste de usuário/senha (não cria sessão, só confere)
if (($_POST['acao'] ?? '') === 'testar') {
    $u = trim($_POST['usuario'] ?? ''); $s = (string) ($_POST['senha'] ?? '');
    echo "\n--- Teste de credenciais ---\n";
    try {
        $st = $pdo->prepare("SELECT f.id, f.nome, f.senha, f.cargo_id FROM funcionarios f WHERE f.usuario = :u LIMIT 1");
        $st->execute([':u' => $u]);
        $f = $st->fetch(PDO::FETCH_ASSOC);
        if (!$f) {
            linha(false, "Usuário '$u' NÃO existe na tabela funcionarios (o login usa a coluna 'usuario', não o nome)");
            $todos = $pdo->query("SELECT usuario FROM funcionarios LIMIT 20")->fetchAll(PDO::FETCH_COLUMN);
            linha(null, 'Usuários existentes: ' . implode(', ', $todos));
        } else {
            linha(true, "Usuário encontrado (id {$f['id']}, {$f['nome']})");
            $info = password_get_info((string) $f['senha']);
            linha($info['algo'] !== null && $info['algo'] !== 0, 'Senha guardada como hash válido? ' . ($info['algoName'] ?? 'unknown') . ' (tamanho ' . strlen((string) $f['senha']) . ')');
            if ($info['algo'] === null || $info['algo'] === 0) {
                linha(false, 'A senha no banco NÃO é um hash bcrypt/argon (provavelmente texto puro ou coluna truncada). password_verify nunca vai bater.');
            }
            linha(password_verify($s, (string) $f['senha']), 'password_verify com a senha digitada');
            $c = $pdo->prepare("SELECT nome FROM cargos WHERE id = :i");
            $c->execute([':i' => $f['cargo_id']]);
            linha(null, 'Cargo: ' . ($c->fetchColumn() ?: '(sem cargo)'));
        }
    } catch (Throwable $e) {
        linha(false, 'Erro na consulta de login: ' . $e->getMessage());
    }
}
echo "</pre>
<form method='post' style='margin-top:10px'>
  <input type='hidden' name='acao' value='testar'>
  <input name='usuario' placeholder='usuário (login)' style='padding:8px'>
  <input name='senha' type='password' placeholder='senha' style='padding:8px'>
  <button style='padding:8px 14px'>Testar credenciais</button>
</form>
<form method='post' style='margin-top:8px'><input type='hidden' name='acao' value='limpar'><button style='padding:8px 14px'>Limpar bloqueio de tentativas</button></form>
</body>";

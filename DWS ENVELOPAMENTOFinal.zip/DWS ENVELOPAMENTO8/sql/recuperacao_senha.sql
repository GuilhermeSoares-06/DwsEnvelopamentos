-- Códigos de "esqueci minha senha" (o PHP também cria esta tabela sozinho se não existir)
CREATE TABLE IF NOT EXISTS recuperacao_senha (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  cliid        INT NOT NULL,
  codigo_hash  VARCHAR(255) NOT NULL,
  expira_em    DATETIME NOT NULL,
  tentativas   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  usado        TINYINT(1) NOT NULL DEFAULT 0,
  ip           VARCHAR(45) NULL,
  criado_em    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_cli (cliid, usado, expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================================
-- schema.sql — RECONSTRUÍDO a partir do código (o projeto original NÃO traz
-- o SQL das tabelas principais). Tudo aqui é SUPOSIÇÃO derivada das colunas
-- que o PHP lê/grava. Compare com o seu banco real antes de usar em produção.
-- =====================================================================
CREATE TABLE IF NOT EXISTS clientes (
  cliid            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  clinome          VARCHAR(255) NOT NULL,
  clicpf           VARCHAR(14)  NULL,
  clitel           VARCHAR(20)  NULL,
  cliendereco      VARCHAR(255) NULL,
  cliemail         VARCHAR(150) NULL,
  clisenha         VARCHAR(255) NOT NULL,
  tipocliente      VARCHAR(20)  NULL DEFAULT 'cliente',
  cli_ip_cadastro  VARCHAR(45)  NULL,
  UNIQUE KEY uq_clientes_cpf (clicpf),
  UNIQUE KEY uq_clientes_email (cliemail)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cargos (
  id   INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS funcionarios (
  id       INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome     VARCHAR(150) NOT NULL,
  usuario  VARCHAR(60)  NOT NULL,
  senha    VARCHAR(255) NOT NULL,
  cpf      VARCHAR(20)  NULL,
  email    VARCHAR(150) NULL,
  telefone VARCHAR(20)  NULL,
  salario  DECIMAL(10,2) NOT NULL DEFAULT 0,
  cargo_id INT UNSIGNED NULL,
  UNIQUE KEY uq_func_usuario (usuario),
  CONSTRAINT fk_func_cargo FOREIGN KEY (cargo_id) REFERENCES cargos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS veiculos (
  vecid     INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  vectipo   ENUM('carro','moto','caminhao','aquatico','mobilia') NOT NULL,
  vecmarca  VARCHAR(60)  NULL,
  vecmodelo VARCHAR(120) NOT NULL,
  vecativo  TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS servicos (
  serid                  INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  cliid                  INT UNSIGNED NOT NULL,
  tipo_servico           VARCHAR(20) NOT NULL,
  vecid                  INT UNSIGNED NULL,
  serdescricao           TEXT NOT NULL,
  servalor               DECIMAL(10,2) NOT NULL DEFAULT 0,
  serstatus_pagamento    VARCHAR(20) NOT NULL DEFAULT 'pendente',
  serstatus_servico      VARCHAR(20) NULL DEFAULT 'pendente',
  serdata_servico        DATETIME NOT NULL,
  sercriado_em           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sermp_preference_id    VARCHAR(100) NULL,
  sermp_payment_id       VARCHAR(50)  NULL,
  sermp_metodo_pagamento VARCHAR(30)  NULL,
  serdata_pagamento      DATETIME NULL,
  KEY idx_ser_data (serdata_servico),
  KEY idx_ser_cli (cliid),
  CONSTRAINT fk_ser_cli FOREIGN KEY (cliid) REFERENCES clientes(cliid),
  CONSTRAINT fk_ser_vec FOREIGN KEY (vecid) REFERENCES veiculos(vecid) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS configuracoes (
  chave VARCHAR(60) NOT NULL PRIMARY KEY,
  valor VARCHAR(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS galeria (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  titulo    VARCHAR(150) NOT NULL,
  descricao TEXT NULL,
  tipo      VARCHAR(20) NOT NULL,
  imagem    VARCHAR(255) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tentativas_login (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  chave     CHAR(32) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_chave (chave, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS faturamento_mensal (
  id                   INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ano                  SMALLINT NOT NULL,
  mes                  TINYINT NOT NULL,
  total_servicos       INT NOT NULL DEFAULT 0,
  faturamento_total    DECIMAL(12,2) NOT NULL DEFAULT 0,
  faturamento_aprovado DECIMAL(12,2) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_mes (ano, mes)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Preços padrão (o painel "Preços" e o agendamento leem estas chaves). INSERT IGNORE: não sobrescreve o que já existe.
-- Requer a PRIMARY KEY em configuracoes.chave (definida acima).
INSERT IGNORE INTO configuracoes (chave, valor) VALUES
 ('preco_carro','800.0000'),('preco_moto','500.0000'),('preco_caminhao','2500.0000'),
 ('preco_aquatico','1800.0000'),('preco_mobilia','300.0000'),
 ('acabamento_brilhante','1.1500'),('acabamento_perolizado','1.3000'),('acabamento_texturizado','1.4000');

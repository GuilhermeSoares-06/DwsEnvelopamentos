-- E-mail do funcionário (usado em "Esqueci minha senha" do painel). O PHP também cria sozinho se faltar.
ALTER TABLE funcionarios ADD COLUMN email VARCHAR(150) NULL;
CREATE TABLE IF NOT EXISTS recuperacao_senha_adm (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  funid INT NOT NULL,
  codigo_hash VARCHAR(255) NOT NULL,
  expira_em DATETIME NOT NULL,
  tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
  usado TINYINT(1) NOT NULL DEFAULT 0,
  ip VARCHAR(45) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fun (funid, usado, expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

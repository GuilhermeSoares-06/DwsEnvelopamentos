#!/bin/bash
cd /tmp; B=http://127.0.0.1:8083; PASS=0; FAIL=0
ok(){ if [ "$2" = "1" ]; then echo "  PASS  $1"; PASS=$((PASS+1)); else echo "  FAIL  $1"; FAIL=$((FAIL+1)); fi; }
b(){ [ "$1" = "$2" ] && echo 1 || echo 0; }
php "$(dirname "$0")/seed.php" >/dev/null
rm -f a.jar c.jar
curl -s -c a.jar -b a.jar -o /dev/null -d "nome=dariel&senha=Admin@123" $B/PHP/ADM/LoginADM.php
curl -s -c c.jar -b c.jar -o /dev/null -d "cpf=52998224725&senha=Senha@123" $B/PHP/Clientes/Logincliente.php
CT=$(curl -s -b c.jar $B/PHP/Clientes/sessao_cliente.php | php -r '$j=json_decode(stream_get_contents(STDIN),true);echo $j["csrf_token"]??"";')
AT=$(curl -s -b a.jar "$B/PHP/Servico/GerenciarServico.php" | grep -oE "[a-f0-9]{64}" | head -1)
echo "T1 busca"
n=$(curl -s -b a.jar "$B/PHP/ADM/ListarPedidos.php?busca=Joao" | grep -c 'class="linha-pedido"'); ok "Pedidos busca=Joao acha 1 (achou $n)" $(b $n 1)
t=$(curl -s -b a.jar "$B/PHP/Clientes/ListarCliente.php?busca=Joao" | grep -oE "Total: <strong>[0-9]+" | grep -oE "[0-9]+$"); ok "Clientes busca=Joao acha 1 (achou $t)" $(b $t 1)
t=$(curl -s -b a.jar "$B/PHP/Clientes/ListarCliente.php?busca[]=x" -o /dev/null -w "%{http_code}"); ok "busca[]= sem erro 500 (HTTP $t)" $(b $t 200)
echo "T2 enumeração"
r1=$(curl -s -d "acao=solicitar&cpf=39053344705" $B/PHP/Clientes/recuperar_senha.php | php -r '$j=json_decode(stream_get_contents(STDIN),true);echo $j["status"];')
ok "CPF inexistente => sucesso genérico ($r1)" $(b $r1 sucesso)
r2=$(curl -s -d "acao=solicitar&usuario=naoexiste" $B/PHP/ADM/recuperar_senha_adm.php | php -r '$j=json_decode(stream_get_contents(STDIN),true);echo $j["status"];'); ok "ADM usuário inexistente => sucesso genérico ($r2)" $(b $r2 sucesso)
echo "T3 pagamento de pedido expirado"
DZ=$(date -d "+20 days" +%F)
mariadb -uroot dws -e "INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico,sercriado_em) VALUES (1,'carro',1,'X','800.00','pendente','$DZ 12:00:00',NOW()-INTERVAL 3 DAY)"
XID=$(mariadb -uroot dws -N -e "SELECT MAX(serid) FROM servicos")
mariadb -uroot dws -e "INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (2,'moto',2,'Y','500.00','pagar_no_local','$DZ 12:00:00')"
r=$(curl -s -b c.jar -H "X-CSRF-Token: $CT" -H "X-Requested-With: XMLHttpRequest" -d "servico_id=$XID&metodo=pix&resultado=ok" $B/PHP/pagamento/simular_pagamento.php -w " %{http_code}"); ok "pedido expirado recusado (409)" $(echo "$r" | grep -q " 409$" && echo 1 || echo 0)
st=$(mariadb -uroot dws -N -e "SELECT serstatus_pagamento FROM servicos WHERE serid=$XID"); ok "status segue pendente ($st)" $(b $st pendente)
mariadb -uroot dws -e "INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (1,'carro',1,'ativo','800.00','pendente','$(date -d '+25 days' +%F) 12:00:00')"
AID=$(mariadb -uroot dws -N -e "SELECT MAX(serid) FROM servicos")
r=$(curl -s -b c.jar -H "X-CSRF-Token: $CT" -H "X-Requested-With: XMLHttpRequest" -d "servico_id=$AID&metodo=pix&resultado=ok" $B/PHP/pagamento/simular_pagamento.php); ok "(regressão) pedido ativo ainda é pago" $(echo "$r" | grep -q '"pagamento":"aprovado"' && echo 1 || echo 0)
echo "T4 finalizar cancelado"
mariadb -uroot dws -e "UPDATE servicos SET serstatus_servico='cancelado' WHERE serid=$XID"
r=$(curl -s -b a.jar -H "X-CSRF-Token: $AT" -H "X-Requested-With: XMLHttpRequest" -d "acao=finalizar&id=$XID" $B/PHP/Servico/GerenciarServico.php -w " %{http_code}"); ok "finalizar cancelado => 409" $(echo "$r" | grep -q " 409$" && echo 1 || echo 0)
echo "T5 fechar_mes"
mariadb -uroot dws -e "TRUNCATE faturamento_mensal; INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (1,'carro',1,'o1','800.00','aprovado','2026-10-15 12:00:00')"
mariadb -uroot dws -e "ALTER TABLE servicos MODIFY servalor VARCHAR(20) NOT NULL DEFAULT '0'"
mariadb -uroot dws -e "INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (1,'carro',1,'o2','1.234,56','aprovado','2026-10-16 12:00:00')"
curl -s -b a.jar $B/PHP/ADM/fechar_mes.php >/dev/null; v=$(mariadb -uroot dws -N -e "SELECT faturamento_aprovado FROM faturamento_mensal"); ok "800.00 + 1.234,56 = 2034.56 (veio $v)" $(b $v 2034.56)
mariadb -uroot dws -e "ALTER TABLE servicos MODIFY servalor DECIMAL(10,2) NOT NULL DEFAULT 0" 2>/dev/null
echo "T6 preços"
mariadb -uroot dws -e "DELETE FROM configuracoes WHERE chave='preco_moto'"
curl -s -b a.jar -H "X-CSRF-Token: $AT" -d "acao=salvar&chave=preco_moto&valor=650" $B/PHP/ADM/GerenciarPrecos.php >/dev/null
v=$(mariadb -uroot dws -N -e "SELECT valor FROM configuracoes WHERE chave='preco_moto'"); ok "preço gravado de verdade ($v)" $(b $v 650.0000)
r=$(curl -s -b a.jar -H "X-CSRF-Token: $AT" -d "acao=salvar&chave=preco_moto&valor=0" $B/PHP/ADM/GerenciarPrecos.php); ok "valor 0 recusado" $(echo "$r" | grep -q erro && echo 1 || echo 0)
echo "T7 cadastro duplicado"
P="nome=Joao Silva&email=novo@teste.com&cpf=529.982.247-25&telefone=(14)99999-1111&cep=&rua=Rua X&numero=1&bairro=Centro&cidade=Piraju&estado=SP&Senha=Senha@123&Senha2=Senha@123"
out=$(curl -s -D /tmp/h.txt -d "$P" $B/PHP/Clientes/CadastroCliente.php)
ok "form recebe HTML amigável" $(grep -qi "text/html" /tmp/h.txt && echo "$out" | grep -q "já está cadastrado" && echo 1 || echo 0)
r=$(curl -s -H "X-Requested-With: XMLHttpRequest" -d "$P" $B/PHP/Clientes/CadastroCliente.php); ok "AJAX continua com JSON" $(echo "$r" | grep -q '"status":"erro"' && echo 1 || echo 0)
echo "T8 funcionários"
w=$(curl -s -b a.jar -d "csrf_token=$AT" $B/PHP/ADM/GerenciarFuncionarios.php | grep -ciE "Warning|Undefined"); ok "POST sem acao sem warnings ($w)" $(b $w 0)
r=$(curl -s -b a.jar -d "csrf_token=$AT&acao=cadastrar&nome=Novo&usuario=novo1&senha=123" $B/PHP/ADM/GerenciarFuncionarios.php | grep -c "pelo menos 8"); ok "senha fraca recusada" $([ "$r" -ge 1 ] && echo 1 || echo 0)
r=$(curl -s -b a.jar -d "csrf_token=$AT&acao=cadastrar&nome=Novo&usuario=novo1&senha=Forte@123" $B/PHP/ADM/GerenciarFuncionarios.php | grep -c "Funcionário cadastrado"); ok "(regressão) senha forte cadastra" $([ "$r" -ge 1 ] && echo 1 || echo 0)
echo "T9 perfil"
curl -s -b c.jar -H "X-CSRF-Token: $CT" -H "X-Requested-With: XMLHttpRequest" -d "id=1&nome=Joao Silva&email=&telefone=(14) 99999-0001&endereco=Rua A" $B/PHP/Clientes/atualizar_perfil.php >/dev/null
v=$(mariadb -uroot dws -N -e "SELECT IFNULL(cliemail,'NULL') FROM clientes WHERE cliid=1"); ok "e-mail vazio => NULL ($v)" $(b $v NULL)
echo "T10 concorrência"
D=$(date -d "+30 days" +%F)
for i in 1 2 3; do ( curl -s -b c.jar -H "X-CSRF-Token: $CT" -H "X-Requested-With: XMLHttpRequest" -d "veiculo_id=1&descricao=t$i&tipo_servico=carro&acabamento=1.0&data_agendamento=$D&tipo_pagamento=local" $B/PHP/Servico/agendar.php >/dev/null ) & done; wait
n=$(mariadb -uroot dws -N -e "SELECT COUNT(*) FROM servicos WHERE DATE(serdata_servico)='$D'"); ok "3 paralelas => 1 agendamento ($n)" $(b $n 1)
echo; echo "RESULTADO: $PASS passaram, $FAIL falharam"

<?php
$pdo = new PDO('mysql:host=127.0.0.1;dbname=dws;charset=utf8mb4','dws','dws123',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$pdo->exec("SET FOREIGN_KEY_CHECKS=0; TRUNCATE servicos; TRUNCATE clientes; TRUNCATE funcionarios; TRUNCATE cargos; TRUNCATE veiculos; TRUNCATE configuracoes; TRUNCATE tentativas_login; TRUNCATE faturamento_mensal; DROP TABLE IF EXISTS recuperacao_senha; DROP TABLE IF EXISTS recuperacao_senha_adm; SET FOREIGN_KEY_CHECKS=1;");
$pdo->exec("INSERT INTO cargos (nome) VALUES ('Gerente'),('Envelopador')");
$h = fn($s)=>password_hash($s, PASSWORD_DEFAULT);
$pdo->prepare("INSERT INTO funcionarios (nome,usuario,senha,email,cargo_id) VALUES ('Dariel Admin','dariel',?,'dariel@teste.com',1)")->execute([$h('Admin@123')]);
$pdo->prepare("INSERT INTO funcionarios (nome,usuario,senha,email,cargo_id) VALUES ('Func Dois','func2',?,NULL,2)")->execute([$h('Func@1234')]);
$c = $pdo->prepare("INSERT INTO clientes (clinome,clicpf,clitel,cliendereco,cliemail,clisenha,tipocliente) VALUES (?,?,?,?,?,?, 'cliente')");
$c->execute(['Joao Silva','52998224725','(14) 99999-0001','Rua A, 1','joao@teste.com',$h('Senha@123')]);
$c->execute(['Maria Souza','11144477735','(14) 99999-0002','Rua B, 2','maria@teste.com',$h('Senha@123')]);
$pdo->exec("INSERT INTO veiculos (vectipo,vecmarca,vecmodelo) VALUES ('carro','Fiat','Uno'),('moto','Honda','CG 160'),('mobilia',NULL,'Geladeira')");
$pdo->exec("INSERT INTO configuracoes (chave,valor) VALUES ('preco_carro','800.0000'),('preco_moto','500.0000'),('preco_caminhao','2500.0000'),('preco_aquatico','1800.0000'),('preco_mobilia','300.0000'),('acabamento_brilhante','1.1500'),('acabamento_perolizado','1.3000'),('acabamento_texturizado','1.4000')");
$d1 = date('Y-m-d', strtotime('+3 days')).' 12:00:00';
$d2 = date('Y-m-d', strtotime('+5 days')).' 12:00:00';
$pdo->prepare("INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (1,'carro',1,'Veiculo: Fiat Uno | teste joao','800.00','aprovado',?)")->execute([$d1]);
$pdo->prepare("INSERT INTO servicos (cliid,tipo_servico,vecid,serdescricao,servalor,serstatus_pagamento,serdata_servico) VALUES (2,'moto',2,'Veiculo: Honda CG | teste maria','500.00','pagar_no_local',?)")->execute([$d2]);
echo "seed ok\n";

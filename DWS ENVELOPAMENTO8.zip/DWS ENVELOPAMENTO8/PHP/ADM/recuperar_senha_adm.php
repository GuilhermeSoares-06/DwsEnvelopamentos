<?php
// =============================================
// recuperar_senha_adm.php — "Esqueci minha senha" do funcionário/ADM (código por e-mail)
// POST acao=solicitar | verificar | redefinir  (resposta JSON)
//   solicitar : usuario                      → envia código de 6 dígitos ao e-mail cadastrado
//   verificar : usuario, codigo              → confere o código (não o consome)
//   redefinir : usuario, codigo, senha, senha2 → grava a nova senha
// Proteções: limite por IP/CPF, código com hash, validade 15 min,
//            máx. 5 erros por código, resposta genérica (não revela se o CPF existe).
// =============================================
require_once __DIR__ . '/../bootstrap.php';

enviarHeadersSeguranca(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responderErro('Método não permitido.', 405);

const REC_VALIDADE_MIN  = 15;
const REC_MAX_ERROS     = 5;
const REC_INTERVALO_SEG = 60;

$acao = (string) ($_POST['acao'] ?? '');
$cpf  = strtolower(preg_replace('/[^a-zA-Z0-9._-]/', '', (string) ($_POST['usuario'] ?? ''))); // login do funcionário
$ip   = ipCliente();

if ($cpf === '' || strlen($cpf) > 60) responderErro('Informe seu usuário de login.');

try {
    garantirColunaEmailFuncionario($pdo);
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS recuperacao_senha_adm (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            funid INT NOT NULL,
            codigo_hash VARCHAR(255) NOT NULL,
            expira_em DATETIME NOT NULL,
            tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
            usado TINYINT(1) NOT NULL DEFAULT 0,
            ip VARCHAR(45) NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cli (funid, usado, expira_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $stmt = $pdo->prepare("
        SELECT id AS funid, nome AS clinome, email AS cliemail FROM funcionarios
        WHERE LOWER(usuario) = :cpf LIMIT 1
    ");
    $stmt->execute([':cpf' => $cpf]);
    $cli = $stmt->fetch(PDO::FETCH_ASSOC);

    // ---------------------------------------------
    if ($acao === 'solicitar') {
        verificarRateLimit('recadm_ip_' . $ip, 5, 3600);
        verificarRateLimit('recadm_cpf_' . $cpf, 3, 3600);
        registrarTentativa('recadm_ip_' . $ip);
        registrarTentativa('recadm_cpf_' . $cpf);

        if (!$cli) responderErro('Usuário não encontrado.');
        if (!validarEmail((string) $cli['cliemail'])) responderErro('Este usuário não tem e-mail cadastrado. Peça ao Super Admin para cadastrar em Funcionários.');

        $ult = $pdo->prepare("SELECT COUNT(*) FROM recuperacao_senha_adm WHERE funid = :c AND criado_em > (NOW() - INTERVAL " . REC_INTERVALO_SEG . " SECOND)");
        $ult->execute([':c' => $cli['funid']]);
        if ((int) $ult->fetchColumn() > 0) {
            responderErro('Um código acabou de ser enviado. Aguarde 1 minuto para pedir outro (veja também o spam).', 429);
        }

        $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $pdo->prepare("UPDATE recuperacao_senha_adm SET usado = 1 WHERE funid = :c AND usado = 0")->execute([':c' => $cli['funid']]);
        $pdo->prepare("
            INSERT INTO recuperacao_senha_adm (funid, codigo_hash, expira_em, ip)
            VALUES (:c, :h, (NOW() + INTERVAL " . REC_VALIDADE_MIN . " MINUTE), :ip)
        ")->execute([':c' => $cli['funid'], ':h' => password_hash($codigo, PASSWORD_DEFAULT), ':ip' => $ip]);
        $idLinha = (int) $pdo->lastInsertId();

        $nome = htmlspecialchars(explode(' ', trim($cli['clinome']))[0], ENT_QUOTES, 'UTF-8');
        $html = '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">'
              . '<h2 style="color:#f23535;margin:0 0 12px">DWS Envelopamento</h2>'
              . "<p>Olá, <b>{$nome}</b>! Use o código abaixo para redefinir sua senha:</p>"
              . '<p style="font-size:34px;letter-spacing:8px;font-weight:bold;text-align:center;background:#f6f6f6;padding:14px;border-radius:10px">' . $codigo . '</p>'
              . '<p style="color:#666;font-size:13px">O código vale por ' . REC_VALIDADE_MIN . ' minutos. Se você não pediu isso, ignore este e-mail — sua senha continua a mesma.</p></div>';

        $enviado = enviarEmail($cli['cliemail'], $cli['clinome'], 'Código para redefinir a senha (painel DWS)', $html,
            "Seu código DWS: {$codigo} (vale " . REC_VALIDADE_MIN . ' minutos).');

        logAuditoria('adm_recuperar_senha_solicitada', ['funid' => $cli['funid'], 'enviado' => $enviado]);

        if (!$enviado) {
            // Só em desenvolvimento: mostra o código e o motivo para testar sem servidor de e-mail
            if (APP_ENV === 'development' && APP_DEBUG) {
                responderSucesso('Código gerado, mas o e-mail NÃO foi enviado.', [
                    'codigo_teste' => $codigo,
                    'erro_email'   => $GLOBALS['dws_erro_email'] ?? '',
                ]);
            }
            // Produção: descarta o código (permite tentar de novo) e avisa com honestidade
            $pdo->prepare("DELETE FROM recuperacao_senha_adm WHERE id = :id")->execute([':id' => $idLinha]);
            responderErro('Não foi possível enviar o e-mail agora. Tente novamente em instantes ou fale com a DWS.', 502);
        }

        $mask = mascararEmail($cli['cliemail']);
        responderSucesso('Enviamos um código de 6 dígitos para ' . $mask . '. Ele vale por ' . REC_VALIDADE_MIN . ' minutos. Não chegou? Veja o spam.', ['email_mascarado' => $mask]);
    }

    // ---------------------------------------------
    // verificar / redefinir — precisam de um código válido
    // ---------------------------------------------
    if (!in_array($acao, ['verificar', 'redefinir'], true)) responderErro('Ação inválida.');

    verificarRateLimit('recadm_ver_' . $cpf, 10, 900);
    verificarRateLimit('recadm_ver_ip_' . $ip, 20, 900);

    $codigo = preg_replace('/\D/', '', (string) ($_POST['codigo'] ?? ''));
    if (strlen($codigo) !== 6) responderErro('Digite o código de 6 dígitos.');

    $linha = null;
    if ($cli) {
        $q = $pdo->prepare("
            SELECT id, codigo_hash, tentativas FROM recuperacao_senha_adm
            WHERE funid = :c AND usado = 0 AND expira_em > NOW()
            ORDER BY id DESC LIMIT 1
        ");
        $q->execute([':c' => $cli['funid']]);
        $linha = $q->fetch(PDO::FETCH_ASSOC);
    }

    $valido = $linha && (int) $linha['tentativas'] < REC_MAX_ERROS && password_verify($codigo, $linha['codigo_hash']);

    if (!$valido) {
        registrarTentativa('recadm_ver_' . $cpf);
        registrarTentativa('recadm_ver_ip_' . $ip);
        if ($linha) {
            $pdo->prepare("UPDATE recuperacao_senha_adm SET tentativas = tentativas + 1 WHERE id = :id")->execute([':id' => $linha['id']]);
            if ((int) $linha['tentativas'] + 1 >= REC_MAX_ERROS) {
                responderErro('Código bloqueado por excesso de erros. Peça um novo código.', 400);
            }
        }
        responderErro('Código inválido ou expirado.', 400);
    }

    if ($acao === 'verificar') {
        responderSucesso('Código confirmado.');
    }

    // ---- redefinir ----
    $senha  = (string) ($_POST['senha'] ?? '');
    $senha2 = (string) ($_POST['senha2'] ?? '');

    if (strlen($senha) < 8)                  responderErro('A senha deve ter pelo menos 8 caracteres.');
    if (!preg_match('/[A-Z]/', $senha))      responderErro('A senha deve ter pelo menos 1 letra MAIÚSCULA.');
    if (!preg_match('/[a-z]/', $senha))      responderErro('A senha deve ter pelo menos 1 letra minúscula.');
    if (!preg_match('/[0-9]/', $senha))      responderErro('A senha deve ter pelo menos 1 número.');
    if (!preg_match('/[^A-Za-z0-9]/', $senha)) responderErro('A senha deve ter pelo menos 1 caractere especial (!@#$…).');
    if ($senha !== $senha2)                  responderErro('As senhas não são iguais.');

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE funcionarios SET senha = :h WHERE id = :c")
        ->execute([':h' => password_hash($senha, PASSWORD_DEFAULT), ':c' => $cli['funid']]);
    $pdo->prepare("UPDATE recuperacao_senha_adm SET usado = 1 WHERE funid = :c")->execute([':c' => $cli['funid']]);
    $pdo->commit();

    limparTentativas('recadm_ver_' . $cpf);
    logAuditoria('adm_recuperar_senha_concluida', ['funid' => $cli['funid']]);
    responderSucesso('Senha alterada com sucesso! Faça login com a nova senha.');

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[recuperar_senha_adm] ' . $e->getMessage());
    responderErro('Erro interno. Tente novamente.', 500);
}

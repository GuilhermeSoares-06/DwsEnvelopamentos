<?php
// =============================================
// Faturamento.php - Painel de faturamento
// =============================================
require_once __DIR__ . '/../bootstrap.php';

enviarHeadersSeguranca();
exigirLoginAdmin();

// 🔥 BLOQUEIO: só os IDs em config('admin.super_admin_ids') veem o faturamento
if (!isSuperAdmin()) {
    header('Location: ../../telas/ADM/principalFun.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Faturamento — DWS Admin</title>
<link rel="icon" type="image/png" href="../../img/logoabas.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: 'Space Grotesk', sans-serif;
    background: #050505;
    color: #fff;
    min-height: 100vh;
    padding: 30px 20px;
    background-image:
        radial-gradient(ellipse at 15% 15%, rgba(242, 53, 53, 0.08) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 85%, rgba(242, 53, 53, 0.05) 0%, transparent 45%);
    background-attachment: fixed;
}

.container { max-width: 1400px; margin: 0 auto; }

.page-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 30px; flex-wrap: wrap; gap: 15px;
}
.page-header h1 {
    font-family: 'Orbitron', sans-serif; font-size: 2rem;
    font-weight: 900; text-transform: uppercase; margin: 0;
}
.page-header h1 i { color: #f23535; margin-right: 12px; }
.page-header h1 span {
    background: linear-gradient(135deg, #fff, #f23535);
    -webkit-background-clip: text; background-clip: text; color: transparent;
}

.actions-header { display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
.filtro-periodo {
    background: #1a1a1a; border: 1px solid #333; color: #fff;
    padding: 10px 18px; border-radius: 10px; font-family: 'Space Grotesk', sans-serif;
    font-size: 0.9rem; outline: none; cursor: pointer; transition: 0.3s;
}
.filtro-periodo:focus { border-color: #f23535; }
.btn-voltar {
    display: inline-flex; align-items: center; gap: 10px;
    padding: 12px 24px; background: rgba(255,255,255,0.05); color: #aaa;
    text-decoration: none; border-radius: 12px; font-size: 0.85rem;
    font-weight: 600; transition: 0.3s; border: 1px solid rgba(255,255,255,0.05);
}
.btn-voltar:hover { background: rgba(242,53,53,0.1); color: #f23535; transform: translateX(-5px); }

.resumo-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px; margin-bottom: 35px;
}
.resumo-card {
    background: linear-gradient(145deg, rgba(20,20,20,0.9), rgba(10,10,10,0.95));
    border-radius: 20px; padding: 25px; border: 1px solid rgba(255,255,255,0.06);
    transition: 0.3s; position: relative; overflow: hidden;
}
.resumo-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: linear-gradient(90deg, transparent, #f23535, transparent);
    transform: scaleX(0); transition: transform 0.4s;
}
.resumo-card:hover::before { transform: scaleX(1); }
.resumo-card:hover {
    transform: translateY(-5px); border-color: rgba(242,53,53,0.3);
    box-shadow: 0 20px 40px rgba(242,53,53,0.1);
}

.resumo-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; }
.resumo-icon {
    width: 45px; height: 45px; border-radius: 12px;
    background: linear-gradient(135deg, rgba(242,53,53,0.15), rgba(242,53,53,0.03));
    border: 1px solid rgba(242,53,53,0.2);
    display: flex; align-items: center; justify-content: center;
    color: #f23535; font-size: 1.2rem;
}
.resumo-label {
    color: #888; font-size: 0.8rem; text-transform: uppercase;
    letter-spacing: 1px; font-family: 'Orbitron', sans-serif;
    font-weight: 600; margin-bottom: 8px;
}
.resumo-valor {
    font-family: 'Orbitron', sans-serif; font-size: 1.8rem; font-weight: 900;
    background: linear-gradient(135deg, #fff, #f23535);
    -webkit-background-clip: text; background-clip: text; color: transparent;
    letter-spacing: -1px;
}

.chart-card {
    background: linear-gradient(145deg, rgba(20,20,20,0.9), rgba(10,10,10,0.95));
    border-radius: 20px; padding: 30px; border: 1px solid rgba(255,255,255,0.06); margin-bottom: 35px;
}
.chart-card h3 {
    font-family: 'Orbitron', sans-serif; font-size: 0.95rem; text-transform: uppercase;
    letter-spacing: 1px; margin-bottom: 25px; padding-bottom: 15px;
    border-bottom: 1px solid rgba(242,53,53,0.15); display: flex; align-items: center; gap: 12px;
}
.chart-card h3 i { color: #f23535; }
.chart-container { position: relative; height: 320px; }

.table-card {
    background: linear-gradient(145deg, rgba(20,20,20,0.9), rgba(10,10,10,0.95));
    border-radius: 20px; padding: 30px; border: 1px solid rgba(255,255,255,0.06);
}
.table-card h3 {
    font-family: 'Orbitron', sans-serif; font-size: 0.95rem; text-transform: uppercase;
    letter-spacing: 1px; margin-bottom: 25px; padding-bottom: 15px;
    border-bottom: 1px solid rgba(242,53,53,0.15); display: flex; align-items: center; gap: 12px;
}
.table-card h3 i { color: #f23535; }

.table-responsive { overflow-x: auto; border-radius: 12px; }
table { width: 100%; border-collapse: collapse; min-width: 700px; }
thead { background: rgba(242,53,53,0.08); }
th {
    text-align: left; padding: 14px 18px; color: #aaa; font-family: 'Orbitron', sans-serif;
    font-size: 0.7rem; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.5px; border-bottom: 1px solid rgba(242,53,53,0.15);
}
td { padding: 14px 18px; color: #ccc; border-bottom: 1px solid rgba(255,255,255,0.04); font-size: 0.9rem; }
tbody tr { transition: 0.2s; }
tbody tr:hover td { background: rgba(242,53,53,0.04); }

.mes-cell { font-family: 'Orbitron', sans-serif; font-weight: 700; color: #fff; }
.faturamento-cell { color: #4CAF50; font-weight: 700; }
.data-cell { color: #666; font-size: 0.85rem; }

.loading { text-align: center; padding: 60px; color: #555; }
.loading i { font-size: 2rem; color: #f23535; animation: spin 1s linear infinite; margin-bottom: 15px; display: block; }
@keyframes spin { to { transform: rotate(360deg); } }

@media (max-width: 768px) {
    body { padding: 20px 12px; }
    .page-header h1 { font-size: 1.4rem; }
    .page-header { flex-direction: column; align-items: flex-start; }
    .actions-header { width: 100%; justify-content: space-between; }
    .resumo-valor { font-size: 1.4rem; }
    .chart-card, .table-card { padding: 20px; }
    .chart-container { height: 250px; }
}
</style>
</head>
<body>

<div class="container">

    <div class="page-header">
        <h1><i class="fas fa-chart-line"></i> <span>Faturamento</span></h1>
        <div class="actions-header">
            <!-- FILTRO DE PERÍODO -->
            <select id="filtroPeriodo" class="filtro-periodo">
                <option value="mes_atual">Mês Atual</option>
                <option value="ultimos_3">Últimos 3 meses</option>
                <option value="ultimos_6">Últimos 6 meses</option>
                <option value="ano_atual">Este Ano</option>
                <option value="todos" selected>Todo o Histórico</option>
            </select>
            
            <a href="../../telas/ADM/principalFun.php" class="btn-voltar">
                <i class="fas fa-arrow-left"></i> Voltar
            </a>
        </div>
    </div>

    <div class="resumo-grid">
        <div class="resumo-card">
            <div class="resumo-header">
                <div class="resumo-icon"><i class="fas fa-calendar-day"></i></div>
            </div>
            <div class="resumo-label">Faturamento no Período</div>
            <div class="resumo-valor" id="resumoPeriodo">R$ 0,00</div>
        </div>

        <div class="resumo-card">
            <div class="resumo-header">
                <div class="resumo-icon"><i class="fas fa-coins"></i></div>
            </div>
            <div class="resumo-label">Total Histórico (Geral)</div>
            <div class="resumo-valor" id="resumoTotal">R$ 0,00</div>
        </div>

        <div class="resumo-card">
            <div class="resumo-header">
                <div class="resumo-icon"><i class="fas fa-chart-bar"></i></div>
            </div>
            <div class="resumo-label">Serviços no Período</div>
            <div class="resumo-valor" id="resumoServicos">0</div>
        </div>
    </div>

    <div class="chart-card">
        <h3><i class="fas fa-chart-area"></i> Evolução Mensal</h3>
        <div class="chart-container">
            <canvas id="graficoFaturamento"></canvas>
        </div>
    </div>

    <div class="table-card">
        <h3><i class="fas fa-list"></i> Detalhamento do Período</h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Mês / Ano</th>
                        <th>Total Serviços</th>
                        <th>Faturamento</th>
                        <th>Fechado em</th>
                    </tr>
                </thead>
                <tbody id="historicoBody">
                    <tr>
                        <td colspan="4">
                            <div class="loading">
                                <i class="fas fa-spinner"></i>
                                Carregando histórico...
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
let dadosHistorico = [];
let meuGrafico = null;

// Inicia com o filtro "Todo o histórico"
document.addEventListener('DOMContentLoaded', () => {
    carregarDados();
    document.getElementById('filtroPeriodo').addEventListener('change', () => {
        renderizarTudo();
    });
});

async function carregarDados() {
    try {
        const resHist = await fetch('historico_faturamento.php', {
            credentials: 'include', cache: 'no-store'
        });
        const dataHist = await resHist.json();

        if (dataHist.status === 'sucesso') {
            // Inverte para o gráfico ficar na ordem correta (mais antigo -> mais novo)
            dadosHistorico = dataHist.historico.reverse();
            renderizarTudo();
        }
    } catch (e) {
        console.error('Erro:', e);
        document.getElementById('historicoBody').innerHTML = `
            <tr>
                <td colspan="4" style="text-align:center;color:#f44336;padding:40px;">
                    <i class="fas fa-exclamation-triangle" style="font-size:1.5rem;display:block;margin-bottom:8px;"></i>
                    Erro ao carregar dados
                </td>
            </tr>
        `;
    }
}

function renderizarTudo() {
    const periodo = document.getElementById('filtroPeriodo').value;
    const hoje = new Date();
    
    let dadosFiltrados = [...dadosHistorico];

    // Lógica do filtro
    if (periodo === 'mes_atual') {
        const mesAtual = (hoje.getMonth() + 1).toString().padStart(2, '0');
        const anoAtual = hoje.getFullYear();
        dadosFiltrados = dadosFiltrados.filter(d => d.mes_ano.includes(`/ ${anoAtual}`) && d.mes_ano.startsWith(obterMesPt(mesAtual)));
    } 
    else if (periodo === 'ultimos_3' || periodo === 'ultimos_6') {
        const limiteMeses = periodo === 'ultimos_3' ? 3 : 6;
        const dataLimite = new Date();
        dataLimite.setMonth(dataLimite.getMonth() - limiteMeses);
        
        dadosFiltrados = dadosFiltrados.filter(d => {
            // Converte "Outubro / 2026" para "2026-10-01"
            const partes = d.mes_ano.split(' / ');
            const mes = obterNumeroMes(partes[0]);
            const ano = partes[1];
            const dataRegistro = new Date(`${ano}-${mes}-01T00:00:00`);
            return dataRegistro >= dataLimite;
        });
    }
    else if (periodo === 'ano_atual') {
        const anoAtual = hoje.getFullYear();
        dadosFiltrados = dadosFiltrados.filter(d => d.mes_ano.includes(`/ ${anoAtual}`));
    }

    // Calcula os totais
    let totalPeriodo = 0;
    let totalServicos = 0;
    
    dadosFiltrados.forEach(h => {
        totalPeriodo += parseFloat(h.faturamento_total || 0);
        totalServicos += parseInt(h.total_servicos || 0);
    });

    // Atualiza os Cards
    document.getElementById('resumoPeriodo').textContent = formatarMoeda(totalPeriodo);
    document.getElementById('resumoServicos').textContent = totalServicos;
    
    // O total histórico sempre mostra tudo (não filtra)
    let totalGeral = 0;
    dadosHistorico.forEach(h => totalGeral += parseFloat(h.faturamento_total || 0));
    document.getElementById('resumoTotal').textContent = formatarMoeda(totalGeral);

    // Atualiza Gráfico e Tabela
    renderizarTabela(dadosFiltrados);
    renderizarGrafico(dadosFiltrados);
}

function formatarMoeda(v) {
    return 'R$ ' + parseFloat(v || 0).toLocaleString('pt-BR', {
        minimumFractionDigits: 2, maximumFractionDigits: 2
    });
}

function renderizarTabela(historico) {
    const tbody = document.getElementById('historicoBody');

    if (!historico || historico.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" style="text-align:center;color:#555;padding:60px;">
                    <i class="fas fa-info-circle" style="font-size:2rem;display:block;margin-bottom:12px;opacity:0.4;"></i>
                    Nenhum registro encontrado neste período.
                </td>
            </tr>
        `;
        return;
    }

    // Inverte de volta para a tabela (mais novo -> mais antigo)
    const historicoTabela = [...historico].reverse();

    tbody.innerHTML = historicoTabela.map(h => `
        <tr>
            <td class="mes-cell">${h.mes_ano}</td>
            <td>${h.total_servicos}</td>
            <td class="faturamento-cell">R$ ${parseFloat(h.faturamento_total).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
            <td class="data-cell">${new Date(h.fechado_em.replace(' ', 'T')).toLocaleDateString('pt-BR')}</td>
        </tr>
    `).join('');
}

function renderizarGrafico(historico) {
    if (meuGrafico) {
        meuGrafico.destroy();
    }

    const ctx = document.getElementById('graficoFaturamento').getContext('2d');

    if (!historico || historico.length === 0) {
        return; // Se não tem dados, deixa em branco
    }

    const labels = historico.map(h => h.mes_ano);
    const dados = historico.map(h => parseFloat(h.faturamento_total || 0));

    const gradiente = ctx.createLinearGradient(0, 0, 0, 320);
    gradiente.addColorStop(0, 'rgba(242, 53, 53, 0.4)');
    gradiente.addColorStop(1, 'rgba(242, 53, 53, 0.02)');

    meuGrafico = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Faturamento',
                data: dados,
                borderColor: '#f23535',
                backgroundColor: gradiente,
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#f23535',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(10, 10, 10, 0.95)',
                    titleColor: '#fff',
                    bodyColor: '#ccc',
                    borderColor: 'rgba(242, 53, 53, 0.5)',
                    borderWidth: 1,
                    padding: 15,
                    titleFont: { family: 'Orbitron', size: 13, weight: '700' },
                    bodyFont: { family: 'Space Grotesk', size: 12 },
                    callbacks: {
                        label: function(context) {
                            return 'R$ ' + context.parsed.y.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: {
                        color: '#666',
                        font: { family: 'Space Grotesk', size: 11 },
                        callback: function(v) {
                            // 🔥 CORREÇÃO DO BUG DO "R$ 1": Agora formata certinho
                            return 'R$ ' + v.toLocaleString('pt-BR', { maximumFractionDigits: 0 });
                        }
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#888', font: { family: 'Orbitron', size: 10, weight: '600' } }
                }
            }
        }
    });
}

// Funções auxiliares para traduzir o mês
function obterMesPt(numeroMes) {
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return meses[parseInt(numeroMes) - 1];
}

function obterNumeroMes(nomeMes) {
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    const index = meses.indexOf(nomeMes);
    return index !== -1 ? (index + 1).toString().padStart(2, '0') : '01';
}
</script>

</body>
</html>
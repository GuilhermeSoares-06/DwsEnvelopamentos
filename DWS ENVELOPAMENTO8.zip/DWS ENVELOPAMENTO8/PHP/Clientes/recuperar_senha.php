<?php
// =============================================
// recuperar_senha.php — "Esqueci minha senha" do cliente (código por e-mail)
// POST acao=solicitar | verificar | redefinir  (resposta JSON)
//   solicitar : cpf                      → envia código de 6 dígitos ao e-mail cadastrado
//   verificar : cpf, codigo              → confere o código (não o consome)
//   redefinir : cpf, codigo, senha, senha2 → grava a nova senha
// Proteções: limite por IP/CPF, código com hash, validade 15 min,
//            máx. 5 erros por código, resposta genérica (não revela se o CPF existe).
// =============================================
require_once __DIR__ . '/../bootstrap.php';

enviarHeadersSeguranca(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responderErro('Método não permitido.', 405);

const REC_VALIDADE_MIN  = 15;
const REC_MAX_ERROS     = 5;
const REC_INTERVALO_SEG = 60;

$acao = (string) ($_POST['acao'] ?? '');
$cpf  = preg_replace('/\D/', '', (string) ($_POST['cpf'] ?? ''));
$ip   = ipCliente();

if (!validarCPF($cpf)) responderErro('Informe um CPF válido.');

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS recuperacao_senha (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            cliid INT NOT NULL,
            codigo_hash VARCHAR(255) NOT NULL,
            expira_em DATETIME NOT NULL,
            tentativas TINYINT UNSIGNED NOT NULL DEFAULT 0,
            usado TINYINT(1) NOT NULL DEFAULT 0,
            ip VARCHAR(45) NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_cli (cliid, usado, expira_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $stmt = $pdo->prepare("
        SELECT cliid, clinome, cliemail FROM clientes
        WHERE clicpf = :cpf AND (tipocliente = 'cliente' OR tipocliente IS NULL) LIMIT 1
    ");
    $stmt->execute([':cpf' => $cpf]);
    $cli = $stmt->fetch(PDO::FETCH_ASSOC);

    // ---------------------------------------------
    if ($acao === 'solicitar') {
        verificarRateLimit('rec_ip_' . $ip, 5, 3600);
        verificarRateLimit('rec_cpf_' . $cpf, 3, 3600);
        registrarTentativa('rec_ip_' . $ip);
        registrarTentativa('rec_cpf_' . $cpf);

        if (!$cli) responderErro('Não encontramos cadastro com esse CPF.');
        if (!validarEmail((string) $cli['cliemail'])) responderErro('Esta conta não tem e-mail cadastrado. Fale com a DWS para atualizar seu cadastro.');

        $ult = $pdo->prepare("SELECT COUNT(*) FROM recuperacao_senha WHERE cliid = :c AND criado_em > (NOW() - INTERVAL " . REC_INTERVALO_SEG . " SECOND)");
        $ult->execute([':c' => $cli['cliid']]);
        if ((int) $ult->fetchColumn() > 0) {
            responderErro('Um código acabou de ser enviado. Aguarde 1 minuto para pedir outro (veja também o spam).', 429);
        }

        $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $pdo->prepare("UPDATE recuperacao_senha SET usado = 1 WHERE cliid = :c AND usado = 0")->execute([':c' => $cli['cliid']]);
        $pdo->prepare("
            INSERT INTO recuperacao_senha (cliid, codigo_hash, expira_em, ip)
            VALUES (:c, :h, (NOW() + INTERVAL " . REC_VALIDADE_MIN . " MINUTE), :ip)
        ")->execute([':c' => $cli['cliid'], ':h' => password_hash($codigo, PASSWORD_DEFAULT), ':ip' => $ip]);
        $idLinha = (int) $pdo->lastInsertId();

        $nome = htmlspecialchars(explode(' ', trim($cli['clinome']))[0], ENT_QUOTES, 'UTF-8');
        $html = '<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;border:1px solid #eee;border-radius:12px">'
              . '<h2 style="color:#f23535;margin:0 0 12px">DWS Envelopamento</h2>'
              . "<p>Olá, <b>{$nome}</b>! Use o código abaixo para redefinir sua senha:</p>"
              . '<p style="font-size:34px;letter-spacing:8px;font-weight:bold;text-align:center;background:#f6f6f6;padding:14px;border-radius:10px">' . $codigo . '</p>'
              . '<p style="color:#666;font-size:13px">O código vale por ' . REC_VALIDADE_MIN . ' minutos. Se você não pediu isso, ignore este e-mail — sua senha continua a mesma.</p></div>';

        $enviado = enviarEmail($cli['cliemail'], $cli['clinome'], 'Seu código para redefinir a senha', $html,
            "Seu código DWS: {$codigo} (vale " . REC_VALIDADE_MIN . ' minutos).');

        logAuditoria('recuperar_senha_solicitada', ['cliid' => $cli['cliid'], 'enviado' => $enviado]);

        if (!$enviado) {
            // Só em desenvolvimento: mostra o código e o motivo para testar sem servidor de e-mail
            if (APP_ENV === 'development' && APP_DEBUG) {
                responderSucesso('Código gerado, mas o e-mail NÃO foi enviado.', [
                    'codigo_teste' => $codigo,
                    'erro_email'   => $GLOBALS['dws_erro_email'] ?? '',
                ]);
            }
            // Produção: descarta o código (permite tentar de novo) e avisa com honestidade
            $pdo->prepare("DELETE FROM recuperacao_senha WHERE id = :id")->execute([':id' => $idLinha]);
            responderErro('Não foi possível enviar o e-mail agora. Tente novamente em instantes ou fale com a DWS.', 502);
        }

        $mask = mascararEmail($cli['cliemail']);
        responderSucesso('Enviamos um código de 6 dígitos para ' . $mask . '. Ele vale por ' . REC_VALIDADE_MIN . ' minutos. Não chegou? Veja o spam.', ['email_mascarado' => $mask]);
    }

    // ---------------------------------------------
    // verificar / redefinir — precisam de um código válido
    // ---------------------------------------------
    if (!in_array($acao, ['verificar', 'redefinir'], true)) responderErro('Ação inválida.');

    verificarRateLimit('rec_ver_' . $cpf, 10, 900);
    verificarRateLimit('rec_ver_ip_' . $ip, 20, 900);

    $codigo = preg_replace('/\D/', '', (string) ($_POST['codigo'] ?? ''));
    if (strlen($codigo) !== 6) responderErro('Digite o código de 6 dígitos.');

    $linha = null;
    if ($cli) {
        $q = $pdo->prepare("
            SELECT id, codigo_hash, tentativas FROM recuperacao_senha
            WHERE cliid = :c AND usado = 0 AND expira_em > NOW()
            ORDER BY id DESC LIMIT 1
        ");
        $q->execute([':c' => $cli['cliid']]);
        $linha = $q->fetch(PDO::FETCH_ASSOC);
    }

    $valido = $linha && (int) $linha['tentativas'] < REC_MAX_ERROS && password_verify($codigo, $linha['codigo_hash']);

    if (!$valido) {
        registrarTentativa('rec_ver_' . $cpf);
        registrarTentativa('rec_ver_ip_' . $ip);
        if ($linha) {
            $pdo->prepare("UPDATE recuperacao_senha SET tentativas = tentativas + 1 WHERE id = :id")->execute([':id' => $linha['id']]);
            if ((int) $linha['tentativas'] + 1 >= REC_MAX_ERROS) {
                responderErro('Código bloqueado por excesso de erros. Peça um novo código.', 400);
            }
        }
        responderErro('Código inválido ou expirado.', 400);
    }

    if ($acao === 'verificar') {
        responderSucesso('Código confirmado.');
    }

    // ---- redefinir ----
    $senha  = (string) ($_POST['senha'] ?? '');
    $senha2 = (string) ($_POST['senha2'] ?? '');

    if (strlen($senha) < 8)                  responderErro('A senha deve ter pelo menos 8 caracteres.');
    if (!preg_match('/[A-Z]/', $senha))      responderErro('A senha deve ter pelo menos 1 letra MAIÚSCULA.');
    if (!preg_match('/[a-z]/', $senha))      responderErro('A senha deve ter pelo menos 1 letra minúscula.');
    if (!preg_match('/[0-9]/', $senha))      responderErro('A senha deve ter pelo menos 1 número.');
    if (!preg_match('/[^A-Za-z0-9]/', $senha)) responderErro('A senha deve ter pelo menos 1 caractere especial (!@#$…).');
    if ($senha !== $senha2)                  responderErro('As senhas não são iguais.');

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE clientes SET clisenha = :h WHERE cliid = :c")
        ->execute([':h' => password_hash($senha, PASSWORD_DEFAULT), ':c' => $cli['cliid']]);
    $pdo->prepare("UPDATE recuperacao_senha SET usado = 1 WHERE cliid = :c")->execute([':c' => $cli['cliid']]);
    $pdo->commit();

    limparTentativas('rec_ver_' . $cpf);
    logAuditoria('recuperar_senha_concluida', ['cliid' => $cli['cliid']]);
    responderSucesso('Senha alterada com sucesso! Faça login com a nova senha.');

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[recuperar_senha] ' . $e->getMessage());
    responderErro('Erro interno. Tente novamente.', 500);
}
